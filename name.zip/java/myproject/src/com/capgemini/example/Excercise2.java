package com.capgemini.example;
import java.util.Scanner;
public class Excercise2 {
    public static int calculateDiffrence(int num1, int num2)
    {
    	if(num1 > num2)
    		return (num1 - num2);
    	return (num2 - num1);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner scan = new Scanner(System.in);
   int num1 = scan.nextInt();
   int sum1 = 0, sum2 = 0;
   for(int i = 1; i <= num1; i++)
   {
	   sum1 += i*i;
   }
   for(int i = 1; i <= num1; i++)
   {
	   sum2 += i;
   }
   sum2 = sum2*sum2;
   System.out.println("Diffrence is: "  + calculateDiffrence(sum1, sum2));
	}

}
