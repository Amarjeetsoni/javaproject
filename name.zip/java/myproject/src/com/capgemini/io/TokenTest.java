package com.capgemini.io;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.util.StringTokenizer;
public class TokenTest {

	public static void main(String[] args) throws Exception {
		
		DataInputStream data = new DataInputStream(new FileInputStream("D:\\fileHandling\\record.txt"));
		String rec = "";
		int r = 1;
		while((rec = data.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(rec, ",");
			System.out.println("Record: " + (r++));
			while(st.hasMoreTokens()) {
				System.out.println(st.nextToken());
			}
			System.out.println();
		}
	}
//         String line = "101,amar,manager sales,45000";
//         StringTokenizer st = new StringTokenizer(line, ",");
//         while(st.hasMoreTokens()) {
//        	 System.out.println(st.nextToken());
//         }
//	}

}
