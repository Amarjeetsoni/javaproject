package com.capgemini.arch.service;

import com.capgemini.arch.bean.EmployeeBean;

public interface IEmployeeService {
  public boolean addEmployee(EmployeeBean bean);
  public java.util.List<EmployeeBean> getEmployees();
  public EmployeeBean findByID(int empid);
}
