package com.capgemini.example;

public class Squre implements Diagram {

	private double num;
	  
	  public void setRad(double n) {
		  this.num = n;
		  
	  }
	  public double getRad() {
		  return num;
	  }
		public double calcArea(double n) {
			return (n * n);
		}
		public double calCircum(double n) {
	    	return (2*n);
	    }
	public static void main(String[] args) {
		Squre dig = new Squre();
		dig.setRad(10);
		System.out.println("Area of Squre: " + dig.calcArea(dig.getRad()));
		System.out.println("Circum of squre: " + dig.calCircum(dig.getRad()));

	}

}
