package com.capgemini.exp;

public class UsernameValidationException extends Exception {
      public UsernameValidationException() {
	  super("invalid username");
    }
      public UsernameValidationException(String message) {
    	  super(message);
      } 
}
