package com.capgemini.inheritance;
class First{
	private int a = 10;
	public int c = 15;
	public void show() {
		System.out.println("From parent " + a);
	}
}
class Second extends First{
	private int b = 25;
	public void show() {
		System.out.println(b);
		System.out.println(b+c);
		System.out.println("From child " + b);
	}
}
public class InheritanceSingle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Second sc = new Second();
    sc.show();
	}

}
