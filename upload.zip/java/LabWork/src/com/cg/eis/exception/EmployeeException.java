package com.cg.eis.exception;

public class EmployeeException extends Exception {
      public EmployeeException() {
            super("user Define Exception");
      }
      public EmployeeException(String str) {
    	  super(str);
      }
}
