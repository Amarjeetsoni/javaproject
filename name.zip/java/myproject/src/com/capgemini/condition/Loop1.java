package com.capgemini.condition;

public class Loop1 {
   public static int square(int n) {
	   return n*n;
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// show all square of a number upto 100
      int num = 10;
//      while(num <= 100) {
//    	  if(num % 2 == 0) {
//    	  System.out.println(square(num));
//    	  }
//    	  num++;
//      }
      int sum = 0;
      while(num >= 1)
      {
    	  sum += square(num) - square(num-1);
    	  num--;
      }
      System.out.println("sum of square of number 1 to 10 is: " + sum);
	}

}
