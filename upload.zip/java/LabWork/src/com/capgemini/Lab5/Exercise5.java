package com.capgemini.Lab5;

import java.util.Scanner;

public class Exercise5 {
     public static void main(String[] args) {
		System.out.print("Enter age of Person: ");
		try {
		Scanner sc = new Scanner(System.in);
		int age = sc.nextInt();
		sc.close();
		if(age < 15)
			throw new Exception("Age of a person should be above 15");
		else
			System.out.println("Age of person is above 15");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
