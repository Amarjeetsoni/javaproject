package com.capgemini.inheritance;

public class Department extends Employee {
	private String dname;
    private double salary;
     
	public Department() {
		
	}
	public Department(int id, String ename, String job, String Dname, double salary) {
		super(id, ename, job);
        this.dname = Dname;
        this.salary = salary;
	}
	
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
     
}
