package com.capgemini.util.lambda;

public class Employee {
   private int id;
   String name;
   double salary;
   String grade;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
    public Employee() {
    	this.id = 101;
    	this.name = "AMAR";
    	this.salary = 45000;
    	this.grade = "A";
	}
	public Employee(int id, String name, double salary, String grade) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", grade=" + grade + "]";
	}
    
}
