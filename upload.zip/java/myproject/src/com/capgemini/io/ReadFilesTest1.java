package com.capgemini.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;

public class ReadFilesTest1 {

	public static void main(String[] args) throws Exception{
		FileReader file = new FileReader("D:\\fileHandling\\first.txt");
		BufferedReader rd = new BufferedReader(file);
		String str = "";
		int num = 1;
		while((str = rd.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(str, "\n");
			System.out.print(num + ".");
			while(st.hasMoreTokens()) {
				System.out.println(st.nextToken());
			}
			num++;
		}
		rd.close();

	}

}
