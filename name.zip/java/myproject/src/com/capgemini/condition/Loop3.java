package com.capgemini.condition;
import java.util.Scanner;
public class Loop3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     /*
      * enter any msg split msg to individual word
      * 
      * */
		Scanner scan = new Scanner(System.in);
		String message = scan.nextLine();
		String list[] = message.split(" ");
		System.out.println("Words are: ");
		for(int i = 0; i < list.length; i++)
		{
			System.out.println(list[i]);
		}
		System.out.println("Next method is: ");
		for(String s: list) {
			System.out.println(s);
		}
	}

}
