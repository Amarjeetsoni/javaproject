package com.capgemini.Lab8;

import java.io.FileReader;
import java.io.FileWriter;

public class copyDataThread extends Thread{
	FileReader fo;
	FileWriter fw;
	public copyDataThread(FileReader fo,FileWriter fw) {
       this.fo = fo;
       this.fw = fw;
    }
	public void run() {
		   try{
	 			int i;
	 			int j = 0;
	 			while((i = fo.read()) != -1) {
	 	        	   if(++j%10 == 0) {
	 	        		  System.out.println("10 characters are copied");
	 	       	          sleep(5000);
	 	        	   }
	 	        	   this.fw.write(i);
	 	           }
	 			System.out.println("::::content copy successfully::::");
	 			fw.close();
	   }catch(Exception e) {
		   System.out.println(e);
	   }
   }
}
