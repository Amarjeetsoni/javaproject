package com.capgemini.thread;

import java.util.Random;

public class Task1 extends Thread{
  public static void main(String[] args) {
	  new Task1().start();
	  new Task1().start();
}
	@Override
	public void run() {
		String colour[] = {"White", "blue", "Black", "Green", "red", "Yellow"};
		try {
			Random rand = new Random();
			int n = rand.nextInt(5);
			while(colour[n] != "red") {
				System.out.println(colour[n]);
				n = rand.nextInt(5);
				sleep(500);
			}
			throw new Exception("Red Colour founded");
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}
    
}
