public class Test7{
  public static void main(String args[]){
   String text = "this is testing data for this area";
  System.out.println("the length of string is: " + text.length());
  System.out.println("the Upper case of string is: " + text.toUpperCase());
  System.out.println("the Lower case of string is: " + text.toLowerCase());
  System.out.println("last Index of a is: " + text.lastIndexOf('a'));
  System.out.println("the last index from 10th elent 'a' is: " + text.lastIndexOf('a', 15));
  System.out.println("the index of 'i' in string: " + text.indexOf('i'));
  System.out.println("the index of 'i' in string: " + text.indexOf('i', 5));
  text = text.concat(" but not this place");
  System.out.println("New string become: " + text);
  System.out.println("substr is: " + text.substring(1,20));
  System.out.println("substr2 is: " + text.substring(10));
  


// comapreison
  String s1 = new String("Number");
  String s2 = "Number";
  System.out.println("the string is " + (s1 == s2));
  System.out.println("the string is " + (s1.equals(s2)));

}
}