package com.capgemini.thread;

public class ThrApp3 implements Runnable{
  public static void main(String[] args) {
	ThrApp3 th = new ThrApp3();         // instance of the class owns runnable
	Thread thread = new Thread(th);              // register runnable with thread
	thread.start();
}

@Override
public void run() {
    	System.out.println("I am inside run....");
    } 
}
   

