package com.capgemini.exp;

public class ExpTest2 {

	public static void main(String[] args) {
		try {
			String arr[] = {"green", "blue", "red", "yellow", "white"};
			for(String colour: arr) {
				if(colour.equals("yellow"))
				throw new Exception(colour + " is not allowed");
				else
					System.out.println(colour);
			}
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}
