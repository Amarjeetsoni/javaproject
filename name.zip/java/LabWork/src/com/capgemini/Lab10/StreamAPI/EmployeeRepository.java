package com.capgemini.Lab10.StreamAPI;

import java.util.HashSet;
import java.util.Set;

public class EmployeeRepository{
   Set<Employee> record = new HashSet<>();
   Set<Department> st = new HashSet<>();
   public EmployeeRepository() {
	   
   }
   protected void addEmployee(Employee emp) {
	   record.add(emp);
   }
  protected void addDepartment(Department d1) {
	   st.add(d1);
  }
   
}
