package com.cg.service;

public interface WithDraw {
    void withdrwAmmount(Double d, String user, String pass);
}
