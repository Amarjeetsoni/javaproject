package com.capgemini.Lab7;

import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Exercise8 {
	public static int[] modifyArray(int[] arr) {
		   Set<Integer> st = new TreeSet<>();
		   for(int i : arr) {
			   st.add(i);
		   }
		   arr = new int[st.size()];
		   Iterator<Integer> itr = st.iterator();
		   int i = 0;
		   while(itr.hasNext()) {
			   arr[i] = itr.next();
			   i++;
		   }
		   return arr;
	   }
		public static void main(String[] args) {
	       Scanner sc = new Scanner(System.in);
	       System.out.println("Enter number of elemets: ");
	       int num = sc.nextInt();
	       int arr [] = new int[num];
	       for(int i = 0; i < num; i++) {
	    	   arr[i] = sc.nextInt();
	       }
	       for(int i : modifyArray(arr)) {
	    	   System.out.print(i + " ");
	       }
	       sc.close();
		}
}
