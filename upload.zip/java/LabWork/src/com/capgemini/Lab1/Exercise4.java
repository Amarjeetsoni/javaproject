package com.capgemini.Lab1;

import java.util.Scanner;

public class Exercise4 {
    public static boolean checkNumber(int number) {
    	int num = number & (number - 1);
    	if(num == 0)
    		return true;
    	return false;
    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int number = sc.nextInt();
		System.out.println(checkNumber(number)?"Entered number is power of 2":"Entered number is not a power of 2");
		sc.close();

	}

}
