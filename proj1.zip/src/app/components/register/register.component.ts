import { Component, OnInit } from '@angular/core';
import { GameService } from '../../services/game.service';
import { stripGeneratedFileSuffix } from '@angular/compiler/src/aot/util';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  play:boolean = false;
  constructor(private gameService: GameService) { }

  ngOnInit() {
  }
  registerPlayer(player){
    this.play = true;
    // parsing from string to int or float
    let amount: number = parseInt(player.amount);

    if(this.play){
      this.gameService.setBalance(amount);
      this.gameService.deductServiceCharge();
      alert('Your Details are Submitted Successfully...!\n Click on Start Playing Link..!');
    }
  }

}
