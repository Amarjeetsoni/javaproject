package com.capgemini.condition;

public class ConditionTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      if(Integer.parseInt(args[0]) > Integer.parseInt(args[1]))
      {
    	  System.out.println("Greater number is: " + Integer.parseInt(args[0]));
      }
      else if(Integer.parseInt(args[0]) < Integer.parseInt(args[1])) {
    	  System.out.println("Greater number is: " + Integer.parseInt(args[1]));
      }
      else
      {
    	  System.out.println("Both number is equal");
      }
		
	}

}
