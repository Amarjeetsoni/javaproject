package com.capgemini.io;

import java.io.FileWriter;

public class ArmstrongNumber {
    public static Boolean check(int num) {
    	int number = 0;
    	int temp = num;
    	while(num > 0) {
    		int flag = num%10;
    		number += flag*flag*flag;
    		num /= 10;
    	}
    	if(number == temp)
    	return true;
    	return false;
    }
	public static void main(String[] args) throws Exception{
		FileWriter fp = new FileWriter("D:\\fileHandling\\armstrong.txt");
		int num = 1;
		while(num <= 500) {
			if(check(num)) {
				System.out.println(num);
				fp.write(num + "\n");
			}
			num++;
		}
		System.out.println("data Stored");
		fp.close();
		

	}

}
