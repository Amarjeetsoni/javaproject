import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { ListUserComponent } from './components/list-user/list-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { SqrtPipe } from './pipes/sqrt.pipe';
import { HttpClientModule } from '@angular/common/http';
import { SearchPipe } from './pipes/search.pipe';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    AddUserComponent,
    ListUserComponent,
    EditUserComponent,
    SqrtPipe,
    SearchPipe      // registering all userdefined components, directives, pipes
  ],
  imports: [
    BrowserModule,     // registering predefined and user defined 
    AppRoutingModule,   // modules for e.g: ReactiveFromsModule, etc
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule   // httpclientmodule for httpcl
  ],
  providers: [],       // Registering userdefined services
  bootstrap: [AppComponent]    // Specifies stratup component
})
export class AppModule { }
