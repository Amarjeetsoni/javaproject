package com.capgemini.exp;

public class FileHandler {

	public static void main(String[] args) {
      try(MyFileResource fr = new MyFileResource()){
    	  fr.openfile();
    	  fr.doTask();
      }catch(Exception e) {
    	  System.out.println(e);
      }
	}

}
