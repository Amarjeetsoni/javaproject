package com.capgemini.arch.dao;

import com.capgemini.arch.bean.EmployeeBean;

public interface IEmployeeDAO {
   public void addEmployee(EmployeeBean emp);    // add employee will be added to collection object
   public java.util.List<EmployeeBean> getEmployees();   // get all elements of collection
   public EmployeeBean getEmployeeById(int empid);      // get specific record form collection
}
