package com.capgemini.util.lambda;

import java.util.HashSet;
import java.util.Optional;

public class ReduceTest1 {

	public static void main(String[] args) {
		HashSet<Employee> emps = new HashSet<>();
		emps.add(new Employee(101, "Amar", 45000, "A"));
		emps.add(new Employee(102, "Satyam", 40000, "A"));
		emps.add(new Employee(104, "Shubham", 50000, "B"));
		emps.add(new Employee(105, "Anuj", 49000, "C"));
		emps.add(new Employee(108, "Venu", 51000, "D"));
		
		Double totalSal = emps.stream().map(e->e.getSalary()).reduce(0.0, Double::sum);
		System.out.println("Total Salary: " + totalSal);
		
		Double highest = emps.stream().map(e->e.getSalary()).reduce(0.0, Double::max);
		System.out.println("Maximum salary: " + highest);
		
		Optional<Double> lowest = emps.stream().map(e->e.getSalary()).reduce(Double::min);
		System.out.println("Minimum salary: " + lowest.get());
	}

}
