package com.capgemini.example;
import java.util.Scanner;
public class Excercise3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner scan = new Scanner(System.in);
     int num = scan.nextInt();
     Check number = new Check();
     if(number.checkNumber(num))
     {
    	 System.out.println("Entered number is a power of two");
     }
     else
     {
    	 System.out.println("Entered number is not a power of two");
     }
	}

}
class Check{
	public boolean checkNumber(int number)
	{
		int sh = (number & (number-1));
		if(sh == 0)
				return true;
		else
			return false;
//		while(number != 1)
//		{
//			if(number % 2 == 0)
//			{
//				number = number/2;
//			}
//			else
//				return false;
//		}
//		return true;
	}
}