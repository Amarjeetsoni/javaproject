package com.capgemini.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Lab7Question5 {
   public static int getSecondSmallest(int arr[]) {
	   List<Integer> li = new ArrayList<>();
	   for(int i = 0; i < arr.length; i++) {
		   li.add(arr[i]);
	   }
	   Collections.sort(li);
	   return li.get(1);
   }
	public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter size of array: ");
       int size = sc.nextInt();
       int arr[] = new int[size];
       System.out.println("Enter elemets: ");
       for(int i = 0; i < size; i++) {
    	   arr[i] = sc.nextInt();
       }
       System.out.println("The 2nd Lowest: " + getSecondSmallest(arr));
       sc.close();
    		   
	}

}
