package com.capgemini.Lab6;

import java.util.Scanner;

public class Exercise3 {
    public static String getImage(String str) {
    	StringBuffer str1 = new StringBuffer(str);
    	return (str + "|" + str1.reverse());
    }
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String str = scan.nextLine();
		System.out.println(getImage(str));
		scan.close();
	}
}
