package com.capgemini.example;

public interface Diagram {
    double calcArea(double n);
    public default double calCircum(double n) {
    	return (2*Math.PI*n);
    }
}
