package com.project.bean;

interface PersonOpr{
	void addPerson(Person p);
	Person[] getPerson();
}

