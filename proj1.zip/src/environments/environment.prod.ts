export const environment = {
  production: true,
  baseURL: "/assets/data/games.json"
};
