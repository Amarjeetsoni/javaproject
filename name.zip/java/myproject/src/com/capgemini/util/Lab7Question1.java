package com.capgemini.util;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Lab7Question1 {
   public static List<String> getValues(Map<Integer, String> mp){
	   List<String> str = new ArrayList<>(mp.values());
	   Collections.sort(str);
	   return str; 
   }
	public static void main(String[] args) {
		Map<Integer, String> mp = new  HashMap<>();
        mp.put(100, "Amar");
        mp.put(89, "Aman");
        mp.put(201, "Ankit");
        mp.put(86, "Vani");
        System.out.println(getValues(mp));
	}

}
