package com.capgemini.util.lambda;

import java.util.Arrays;

public class ReduceTest {

	public static void main(String[] args) {
      int arr[] = {10,20,30,15,50};
      Arrays.stream(arr).reduce((x,y)->x+y).ifPresent(x->System.out.println(x));
      Arrays.stream(arr).reduce(Integer::sum).ifPresent(x->System.out.println(x));
	}

}
