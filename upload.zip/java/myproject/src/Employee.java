import java.util.*;

class Employee{
    
	private int id,salary;
    private String name,job;
    public Employee(){
        
    }
    public Employee(int Id, int Salary, String name, String job){
        this.id = Id;
        this.salary = Salary;
        this.name = name;
        this.job = job;
    }
    protected int getId(){
        return this.id;
    }
    protected void setId(int Id){
        this.id = Id;
    }
    protected int getSalary(){
        return this.salary;
    }
    protected void setSalary(int Salary){
        this.salary = Salary;
    }
    protected String getName(){
        return this.name;
    }
    protected void setName(String name){
        this.name = name;
    }
     protected String getJob(){
        return this.job;
    }
    protected void setJob(String job){
        this.job = job;
    }
    
    @Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + ", name=" + name + ", job=" + job + "]";
	}
}
