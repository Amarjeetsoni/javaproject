package com.capgemini.basic;
public class StaticTest2 {
   private Message meg;
	public void myMessage(Message msg) {
	   this.meg = msg;
	   System.out.println(Message.sendMessage());
	   System.out.println(meg.invite("my name"));
   }
	public void square(int n)                          // instance property
   {
	   System.out.println("Square = " + (n*n));
   }
   public static int cube(int n)                     // class property
   {
	   return (n*n*n);
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.out.println("Cube of a number is :" + cube(10));   // class property can call directly
     StaticTest2 t = new StaticTest2();
     System.out.println("square of number: ");  
     t.square(10);
    Message m1 = new Message();
    System.out.println(Message.sendMessage());
    System.out.println(Message.number);
    System.out.println( m1.invite("Amar soni"));
    t.myMessage(m1);                      // instance of Message class is passed as arguments

    t.myMessage(new Message());           // anonymous instance passed as argument
	}

}
class Message{
	static int number = 10;
	private String messageMe() {          // private non static instance method
		System.out.println("Hi i am local member");
		return "HI...";
	}
	public static String sendMessage() {   //static or class property
//		messageMe();
		return "Hello" ; 
		
	}
	public String invite(String name) {   // public instance property
		return "Welcome to " + name;
	}
}
