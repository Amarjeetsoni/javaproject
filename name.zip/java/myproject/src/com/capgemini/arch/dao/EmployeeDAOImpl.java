package com.capgemini.arch.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.capgemini.arch.bean.EmployeeBean;


public class EmployeeDAOImpl implements IEmployeeDAO {
    private static HashMap<Integer, EmployeeBean> emps = new HashMap<>();
	@Override  
	public void addEmployee(EmployeeBean emp) {
     emps.put(emp.getEmpid(), emp);      
	}

	@Override
	public List<EmployeeBean> getEmployees() {
         
		return new ArrayList<EmployeeBean>(emps.values());
	}

	@Override
	public EmployeeBean getEmployeeById(int empid) {
		return emps.get(empid) ;
	}

}
