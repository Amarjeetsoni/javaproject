public class Test5
{
  public static void main(String args[])
{
   String num = new String("40");
   int a = Integer.parseInt(num);
   int b = Integer.parseInt(args[1]);
   System.out.println(a+b);
   System.out.println("Sum is: " + a+b);
   System.out.println("Sum is: " + (a+b));


   // Integer obj = new Integer(30);
   Integer obj = a+b;
   System.out.println("Boxed value is: " + obj);
   int c = (++obj + obj++);
   System.out.println("Unboxed value is: " + c);

  // TYPE COSTING
 float con = c;
 System.out.println("conversion is: " + con);

  // digit sepration
   int my_id = 101_23_1;
   System.out.println("number is: " + (my_id+2));
}

}