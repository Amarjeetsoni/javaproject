import java.util.Scanner;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter the number of elements: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int sum = 0;
		for(int i = 0; i < num; i++)
		{
			System.out.println("Enter " + (i+1) + "th elements: ");
			int number = sc.nextInt();
			sum += number;
		}
		System.out.println("Sum of numbers: " + sum);

	}

}
