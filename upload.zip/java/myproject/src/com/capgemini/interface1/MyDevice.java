package com.capgemini.interface1;
interface Message{
	String sendMesg(String name);
}
public class MyDevice implements Calculator, Message {

	public int addNumber(int x, int y) {
		return (x+y);
	}
//	public int square(int x) {
//		return x*x;
//	}

	public static void main(String[] args) {
//           MyDevice device  = new MyDevice();
		   NewClass device = new NewClass();
           System.out.println(device.addNumber(5, 10));
           System.out.println(device.square(6));
           System.out.println(device.sendMesg("AMAR"));
	}

}
 class NewClass extends MyDevice
{
	public int square(int x) {
		return x*x;
	}
	public String sendMesg(String name)
	{
		return ("Hello!.." + name);
	}
}
