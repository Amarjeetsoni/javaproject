import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GameListComponent } from './components/game-list/game-list.component';
import { Game } from './models/game.model';
import { RegisterComponent } from './components/register/register.component';


const routes: Routes = [
  {path: '', component:RegisterComponent},
  {path: 'games/.gameId', component:GameListComponent},
  {path: 'register', component:RegisterComponent},
  {path: '**', component:GameListComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
