package com.capgemini.Lab6;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class Exercise6 {
    public static void main(String[] args) {
    	try {
		FileInputStream file = new FileInputStream("D:\\fileHandling\\first.txt");
		DataInputStream data = new DataInputStream(file);
		String str = "";
		int line = 0, word = 0, chara = 0;
		while((str = data.readLine()) != null) {
//			System.out.println(str);                // content of file
			chara += str.length();
			word += str.split(" ").length;
			line++;
		}
		System.out.println("Number of lines: " + line + "\nNumber of Word: " + word + "\nNumber of character: " + chara);;
		data.close();
    	}catch(Exception e) {
    		System.out.println(e);
    	}
	}
}
