import java.util.*;
public class Test2
{
 public static void main(String args[])
{
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter a number: ");
  int num = sc.nextInt();
  System.out.println("Entered number is: " + num);
    
}
}