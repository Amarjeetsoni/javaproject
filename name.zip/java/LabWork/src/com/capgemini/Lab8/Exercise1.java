package com.capgemini.Lab8;

public class Exercise1 {

}
