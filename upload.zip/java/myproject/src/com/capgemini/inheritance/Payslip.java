package com.capgemini.inheritance;

public class Payslip extends Department {
    Payslip(){
    	
    }
	public Payslip(int id, String ename, String job, String Dname, double salary) {
		super(id, ename, job, Dname, salary);
		// TODO Auto-generated constructor stub
	}
	public void showPayslip() {
		System.out.println("Employee Id: " + getId());
		System.out.println("Employee Name: " + getEname());
		System.out.println("Employee Job: " + getJob());
		System.out.println("Departments: " + getDname());
		System.out.println("Salary: " + getSalary());
	}

}
