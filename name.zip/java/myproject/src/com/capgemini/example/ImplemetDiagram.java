package com.capgemini.example;

public class ImplemetDiagram implements Diagram {
  private double num;
  
  public void setRad(double n) {
	  this.num = n;
	  
  }
  public double getRad() {
	  return num;
  }
	public double calcArea(double n) {
		return (Math.PI * n * n);
	}

	public static void main(String[] args) {
		ImplemetDiagram dig = new ImplemetDiagram();
		dig.setRad(2.5);
		System.out.println("Area of circule: " + dig.calcArea(dig.getRad()));
		System.out.println("Circum of circle: " + dig.calCircum(dig.getRad()));

	}

}
