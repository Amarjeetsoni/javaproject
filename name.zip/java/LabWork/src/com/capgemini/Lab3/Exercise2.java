package com.capgemini.Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise2 {

	public static void main(String[] args) {
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter Number of String: ");
	  int size = sc.nextInt();
	  String str[] = new String[size];
      
      for(int i = 0; i < size; i++) {
    	  str[i] = sc.next();
      }
      Arrays.sort(str);
      int mid;
      if(size % 2 == 0) {
    	  mid = size/2;
      }
      else
    	  mid = (size/2) + 1;
      
      for(int i = 0; i < mid; i++) {
    	  str[i] = str[i].toUpperCase();
      }
      System.out.println("Final Strings: ");
      for(int i = 0; i < size; i++) {
    	  System.out.println(str[i]);
      }
      sc.close();
      
	}

}
