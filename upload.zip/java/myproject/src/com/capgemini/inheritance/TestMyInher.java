package com.capgemini.inheritance;
interface MyInfo{
	public String invite(String name);
	public default String msg(String number) {
		return ("Hello! " + number);
	}
}
public class TestMyInher {

	public static void main(String[] args) {
              MyInfo inf = new MyInfo() {
            	  public String invite(String name) {
            		  return ("Welcom to " + name);
            	  }
              };
              System.out.println(inf.invite("AMAR"));
              System.out.println(inf.msg("AMARJEET"));
	}

}
