package com.capgemini.thread;

class ThrPriTest extends Thread{
	public ThrPriTest(int prior, String name) {
		start();
		setPriority(prior);
		setName(name);
	}
	public void run() {
		try {
			for(int i = 1; i <= 5; i++) {
				System.out.println(getName() + ">>" + i);
//				 sleep(300);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
public class ThrApp4 {

	public static void main(String[] args) {
       new ThrPriTest(1, "One");
       new ThrPriTest(5, "Two");
       new ThrPriTest(10, "Three");
	}

}
