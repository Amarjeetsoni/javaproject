import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // Implecitly typed, title will be string type
  // If you don't define any value to typeScript then it will take undefined type
 title = "Welcome to LogIn Details management System";

  constructor() { }

  ngOnInit(): void {
  }

}
