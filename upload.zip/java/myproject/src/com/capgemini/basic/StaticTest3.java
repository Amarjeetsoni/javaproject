package com.capgemini.basic;
import static java.lang.System.out;
import static com.capgemini.basic.StaticTest2.cube;
public class StaticTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      out.println("Hello! all..");
      out.print(cube(4));
      
      
	}

}
