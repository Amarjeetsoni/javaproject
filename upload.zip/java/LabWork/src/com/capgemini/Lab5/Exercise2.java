package com.capgemini.Lab5;

import java.util.Scanner;

public class Exercise2 {
       public static int recursivefibo(int num) {
    	   if(num == 1 || num == 2)
    		   return 1;
    	   return (recursivefibo(num-1) + recursivefibo(num-2));
       }
       public static int nonRecursivefibo(int num) {
    	   if(num == 1 || num == 2)
    		   return 1;
    	   int num1 = 1;
    	   int num2 = 1;
    	   int number = 0;
    	   for(int i = 3; i <= num; i++)
    	   {
    		   number = num1 + num2;
    		   num1 = num2;
    		   num2 = number;
    	   }
    	   return number;
       }
       public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int num = scan.nextInt();
		System.out.println(num + "th febo number(recursive): " + recursivefibo(num) + "\n" + num + "th febo number(nonrecursive): " + nonRecursivefibo(num));
		scan.close();
	}
       
}
