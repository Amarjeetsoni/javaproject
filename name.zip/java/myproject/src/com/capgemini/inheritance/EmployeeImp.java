package com.capgemini.inheritance;

public class EmployeeImp {

	public static void main(String[] args) {
//		Department dept = new Department(101, "amar" , "manager", "sales" , 45000);
//		System.out.println("Employee Id: " + dept.getId());
//		System.out.println("Employee Name: " + dept.getEname());
//		System.out.println("Employee Job: " + dept.getJob());
//		System.out.println("Departments: " + dept.getDname());
//		System.out.println("Salary: " + dept.getSalary());
//		
//		Department dept1 = new Department();
//		dept1.setId(101);
//		dept1.setEname("Amar");
//		dept1.setJob("Sales");
//		dept1.setDname("Sales");
//		dept1.setSalary(45000);
//		System.out.println("Employee Id: " + dept.getId());
//		System.out.println("Employee Name: " + dept.getEname());
//		System.out.println("Employee Job: " + dept.getJob());
//		System.out.println("Departments: " + dept.getDname());
//		System.out.println("Salary: " + dept.getSalary());
		
		
		Payslip ps = new Payslip(101, "amar", "Sales", "Sales", 45000);
		ps.showPayslip();
		
		PartTimeEmployee pe = new PartTimeEmployee(1000, "AMARJEET", "SALES", 12, 45000);
		pe.viewDetails();
		Department dept1 = new Payslip(101, "amar", "Sales", "Sales", 45000);  // only common function is allowed
//		Payslip cs = (Payslip) new Department();  // runtime error 
		Payslip pt = (Payslip)dept1;
//		cs.showPayslip();
		pt.showPayslip();
		System.out.println(dept1 instanceof  Employee);
		System.out.println(dept1 instanceof  Payslip);
		System.out.println(ps instanceof Department);
//		System.out.println(Department instanceof ps);
		
		
		
		
		
	}

}
