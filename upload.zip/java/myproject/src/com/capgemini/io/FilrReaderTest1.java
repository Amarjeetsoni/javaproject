package com.capgemini.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;

public class FilrReaderTest1 {
    public static void main(String[] args) throws Exception {
		FileReader reader = new FileReader("D:\\fileHandling\\first.txt");
		BufferedReader buffer = new BufferedReader(reader);
		String str = "";
		while((str = buffer.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(str, ",");
			while(st.hasMoreTokens()) {
				System.out.println(st.nextToken());
			}
		
		}
		buffer.close();
	}
}
