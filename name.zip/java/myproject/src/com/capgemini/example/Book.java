package com.capgemini.example;

public class Book extends WrittenItem {
    
	public Book(int identificationNumber, String title, int numberOfCopy, String author) {
		super(identificationNumber, title, numberOfCopy, author);
	}
	public void print() {
    	System.out.println("identification number: " + identificationNumber + "\ntitle: " + Title + "\nnumber of copy: " + numberOfCopy + "\nauthor: " + getAuthor());
    }


}
