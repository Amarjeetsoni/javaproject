package com.capgemini.thread;

import java.util.Scanner;

class Bank{
	public static int amount;
	String names[] = {"amar", "ankit", "aman", "Avinash", "saurabh"};
	public Bank(int Rs) {
		Bank.amount = Rs;
	}
	public void withDraw(String name) {
    	try {
    		int num = 0;
    		for(String str: names) {
    			if(str.equals(name))
    				num++;
    		}
    		if(num != 0)
    		{
    			System.out.println("Username Varified..");
    		}
    		else
    			throw new Exception("Invalid user name");
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
}

class BankOperation extends Thread{
		public void withDraw(int amount) {
		  try {
			  int money = Bank.amount;
			  if(amount > money) {
				  throw new Exception("Insufficent balence");
			  }else
			  {
				  Bank.amount = money - amount;
			  }
			  start();
		  }catch(Exception E) {
			  System.out.println(E);
		  }
		}
		
		public void run() {
			System.out.println("Final amount: " + Bank.amount);
			System.out.println("Transation completed");
		}
		
}
public class Operation {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter User Name: ");
	String str = sc.next();
	Bank b = new Bank(50000);
	try{ 
		b.withDraw(str);
	System.out.println("1. checkBalence\n2. withDrawamount");
	int num = sc.nextInt();
	BankOperation b1 = new BankOperation();
	if(num == 1) {
		System.out.println(b.amount);
		b1.run();
	}
	else if(num == 2) {
		System.out.println("Enter amount: ");
		int rs = sc.nextInt();
		b1.withDraw(rs);
	}
	else
	{
		System.out.println("Invalid choise");
	}
	}catch(Exception e)
	{
		System.out.println(e);
	}
	
	
}
}
