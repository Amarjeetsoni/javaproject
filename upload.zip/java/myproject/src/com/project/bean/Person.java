package com.project.bean;

public class Person {
    public String Id, name, job;
    
}

