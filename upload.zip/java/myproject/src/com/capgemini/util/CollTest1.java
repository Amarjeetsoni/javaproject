package com.capgemini.util;

import java.util.ArrayList;

public class CollTest1 {

	public static void main(String[] args) {
       ArrayList<String> list = new ArrayList<>();
       list.add("One");
       list.add("12.45");
       list.add("670");
       list.add("a");
       System.out.println("direct print elemets: ");
       System.out.println(list);
       System.out.println("General for loop: ");
       for(int i = 0; i < list.size(); i++)
       {
    	   System.out.println(list.get(i));
       }
       System.out.println("For each loop: ");
       for(String obj: list) {
    	   System.out.println(obj);
       }
       System.out.println("For each for lambda");
       list.forEach(System.out::println);
       list.clear();
       System.out.println(list);
       
       ArrayList<String> dayList = new ArrayList<>();
       dayList.add("Mon");
       dayList.add("tue");
       list.addAll(dayList);
       list.add("670");
       list.remove("12.45");
       System.out.println("Foreach lambda Expression: ");
       list.forEach(System.out::println);
	}
}
