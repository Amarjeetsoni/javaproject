package com.capgemini.Lab5;
import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;
public class Exercise6 {
       public static void CheckSalary(int salary) throws EmployeeException{
    	   if(salary < 3000)
    		   throw new EmployeeException("the salary is below 3000");
    	   else
    		   System.out.println("The salary is above 3000");
    	   
       }
       public static void main(String[] args) {
		try {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter salary: ");
			int salary = scan.nextInt();
			scan.close();
			CheckSalary(salary);
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
