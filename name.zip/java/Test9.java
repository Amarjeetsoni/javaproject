public class Test9{
public static void main(String args[]){
   String msg = "hello members";
   StringBuffer sb = new StringBuffer(msg);  
   System.out.println(msg);
   System.out.println(sb + " " + sb.hashCode());
   System.out.println(sb.append("learn java") + " " + sb.hashCode());
   System.out.println(sb.insert(6, "my new") + " " + sb.hashCode());
   System.out.println(sb.delete(6,9) + " " + sb.hashCode());
   System.out.println(sb.reverse());
   System.out.println(sb.capacity());
   System.out.println(sb.length());
}
}