package com.capgemini.util.lambda;

public interface Greater {
    int findMax(int a, int b);
}
