package com.capgemini.condition;
import java.util.Scanner;
public class ConditionalTest3 {
	public static void main(String args[]) {
		System.out.println("Enter ISD code: ");
		Scanner scan = new Scanner(System.in);
		int isdCode = scan.nextInt();
		System.out.println("Enter STD code: ");
		int stdCode = scan.nextInt();
		if(isdCode == 91) {
			if(stdCode == 22) {
				System.out.println("Pune");
			}
			else if(stdCode == 44) {
				System.out.println("Jalandhar");
			}
			else
			{
				System.out.println("In side india but place does not known");
			}
		}
		else
		{
			System.out.println("Other Country");
		}
	}
	

}
