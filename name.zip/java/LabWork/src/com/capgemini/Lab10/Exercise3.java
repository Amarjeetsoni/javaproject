package com.capgemini.Lab10;

import java.util.Scanner;

interface checkPassword{
	static String username = "user123";
	static String password = "capgemini";
	boolean enter(String username, String password);
}
public class Exercise3 {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Username: ");
	String user = sc.next();
	System.out.print("Password: ");
    String pass = sc.next();
    sc.close();
    checkPassword cp = (a,b) -> {
    	if(checkPassword.username.equals(a) && checkPassword.password.equals(b))
			return true;
		return false;
	};
	if(cp.enter(user, pass)) {
		System.out.println("Welcome....");
	}
	else
		System.out.println("Username/Password wrong please try again...");
}
}
