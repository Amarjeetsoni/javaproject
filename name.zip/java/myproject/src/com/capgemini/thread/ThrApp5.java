package com.capgemini.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class MyRunner implements Runnable{
	@Override
	public void run() {
        System.out.println("Runnable Started");		
	}
	
}
public class ThrApp5 {

	public static void main(String[] args) {
       ExecutorService execute = Executors.newCachedThreadPool();
       execute.execute(new MyRunner());
       Runnable r =()->{
    	 for(int i = 1; i <= 5; i++) {
    		 System.out.println(i);
    	 }
       };
       execute.execute(r);
       execute.shutdown();
	}

}
