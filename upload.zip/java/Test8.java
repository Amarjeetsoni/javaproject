public class Test8{
  public static void main(String args[]){
   String username = "admin";
   String password = "admin";
  System.out.println(username.equals(password));
  System.out.println(username.equals("Admin"));
  System.out.println(username.equalsIgnoreCase("Admin"));

  int n = 10;
  String s = String.valueOf(n);
  System.out.println("Entered number is: " + s);
  String s2 = "first " + "next";
  System.out.println("Entered number is: " + s2);
  String str = "first".concat(" ").concat("second");
  System.out.println("Entered number is: " + str);
 }

}