import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { ListUserComponent } from './components/list-user/list-user.component';

// defines routers for your components
//defines array of objects of routers
const routes: Routes = [
  // empty routes
  // {path: 'Amarjeet',component: HomeComponent},
  {path: '',component: HomeComponent},
  {path: 'home',component: HomeComponent},
  {path: 'login',component: LoginComponent},
  {path: 'add-user',component: AddUserComponent},
  // {path: 'edit-user',component: EditUserComponent},
  {path: 'edit-user/:id',component: EditUserComponent},
  // {path: 'edit-user/:User',component: EditUserComponent},
  {path: 'list-user',component: ListUserComponent},
  // Defalult route
  // {path: '**', component: HomeComponent},
  {path: '**', redirectTo:'/home', pathMatch: 'full'}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
