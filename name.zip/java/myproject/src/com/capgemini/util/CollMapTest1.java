package com.capgemini.util;

import java.util.Map.Entry;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Iterator;
public class CollMapTest1 {

	public static void main(String[] args) {
             Map<Integer, String> mp = new TreeMap<>();
             mp.put(100, "Aman");
             mp.put(89, "Amar");
             mp.put(201, "Ankit");
             mp.put(86, "Vani");
             System.out.println(mp);
             System.out.println(mp.get(100));
//             Set<Int          eger> keys= mp.keySet();
//             Iterator<Integer> itrKeys = keys.iterator();
             
             Iterator<Integer> itr=  mp.keySet().iterator();    // Methods of extracting key and values
             while(itr.hasNext()) {
            	 int key = itr.next();
            	 System.out.println("Key: "+  key + " Value: " + mp.get(key));
             }
             
             Set<String> val = new HashSet<>(mp.values());    // extracting values
             System.out.println(val);
             
             Iterator<Map.Entry<Integer, String>> enter = mp.entrySet().iterator();
             while(enter.hasNext()) {
            	 Entry<Integer, String> e = enter.next();
            	 System.out.println(e.getKey() + " " + e.getValue());
             }
	}

}
