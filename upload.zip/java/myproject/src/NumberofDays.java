import java.util.Scanner;

public class NumberofDays {
    public static boolean isLeap(int num) {
    	if(num % 4 == 0) { 
    		if(num % 100 == 0) { 
    			if(num % 400 == 0)
    		      return true;
    			else 
    				return false;
    		}else
    			return true;
    	}else
    		return false;
    		
    	}
    
	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	int date = scan.nextInt();
	int month = scan.nextInt();
	int year = scan.nextInt();
	int arr[];
	if(isLeap(year))
	{
		arr = new int[]{31,28,31,30,31,30,31,31,30,31,30,31};
	}
	else
	{
		arr = new int[]{31,29,31,30,31,30,31,31,30,31,30,31};
	}
	int cD = 16, cM = 1, cY = 2020;
	int DD = cD - date;
	int DM = cM - month;
	int DY = cY - year;
	if(DY < 0){
		System.out.println("You have Entered future date");
	}
	else {
		if(DD < 0) {
			if(DM < 0) {
				DD = DD + arr[DM-1];
				DM = DM + 11;
				DY = DY - 1;
			}
			else {
				DD = DD + arr[DM - 1];
				DM = DM - 1;
			}
		}
		if(DM < 0) {
			DM = DM + 12;
		}
		System.out.println("Year: " + DY + "\nMonth: " + DM + "\nDay: " + DD);
	}
	

	}

}
