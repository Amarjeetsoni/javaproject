import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  // template: '<h1> Welcome to my Product Management app</h1>'   // multiple  back ude krenge
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
  // providers: ['./calculator']
})
export class AppComponent {
  title = 'LogIn Details Managements apps';     // instance variable
  fullName = "Amarjeet Soni";
  // creating date object
  todaysDate = new Date();
  //only one construct for a class
  // constructor can not be overloaded
  constructor(){
    // setInterval() asynchronous function
    // arrow function ( => )
    setInterval(()=>{
      this.todaysDate = new Date();
    },1000);
  }
}
