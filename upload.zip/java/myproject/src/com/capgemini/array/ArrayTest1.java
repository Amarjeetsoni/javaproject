package com.capgemini.array;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
public class ArrayTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Integer arr[] = {12,34,25,15,89,14};
       System.out.println("array element: ");
       for(int i: arr)
       {
    	   System.out.print(i + " ");
       }
       System.out.println("\nsorted array: ");
       Arrays.sort(arr);
       for(int i: arr)
       {
    	   System.out.print(i + "  ");
       }
       Arrays.sort(arr, Collections.reverseOrder());
       System.out.println("\nreverse sorted array: ");
       for(int i: arr)
       {
    	   System.out.print(i + "  ");
       }
	}

}
