import java.util.*;

public class EmployeeMain{
    public static void main(String args[]){
        Employee emp[] = new Employee[5];
        emp[0] = new Employee(101, 20000, "Ram", "Marketing");
        emp[1] = new Employee(102, 25000, "Ramesh", "HR");
        emp[2] = new Employee(103, 26000, "Amar", "HR");
        emp[3] = new Employee(104, 22000, "Ankit", "Maketing");
        emp[4] = new Employee(105, 23000, "Avinash", "Sales");
        for(int i = 0; i < 5; i++) {
        	System.out.println(emp[i]);
        }
        HashSet<Employee> setEmpl = new HashSet<>();
        for(Employee e: emp) {
        	setEmpl.add(e);
        }
        long sumSalary = setEmpl.stream().map(e->e.getSalary()).distinct().reduce(0,Integer::sum);
        double avg = (double)sumSalary/setEmpl.size();
        System.out.println("Salary above average salary: ");
        setEmpl.stream().filter(e->e.getSalary() > avg).forEach(e->System.out.println(e));
        Optional<Integer> minSala = setEmpl.stream().map(e->e.getSalary()).reduce(Integer::min);
        long minNumber = minSala.get();
        System.out.println("Person With minimum salary: ");
        setEmpl.stream().filter(e->(e.getSalary()==minNumber)).forEach(e->System.out.println(e));
        
    }
}