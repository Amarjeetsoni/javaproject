runpackage com.capgemini.util.lambda;
@FunctionalInterface
interface Age{
	boolean validAge(int a);
}
public class FindValidAge {

	public static void main(String[] args) {
		Age age = (a) -> {return (a>18?true:false);};
		System.out.println("Age is greater then 18 or not: " + age.validAge(21));

	}

}
