package com.capgemini.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Iterator;

public class Lab7Question3 {
public static Map<Integer, Integer> getSquares(int arr[]){
	Map<Integer, Integer> mp = new HashMap<>();
	for(int i = 0; i < arr.length; i++) {
		mp.put(arr[i], arr[i]*arr[i]);
	}
	return mp;
}
	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the size of an array: ");
    int size = sc.nextInt();
    int arr[] = new int[size];
    for(int i = 0; i < size; i++) {
    	arr[i] = sc.nextInt();
    }
    Map<Integer, Integer> mp = new HashMap<>(getSquares(arr));
    Iterator<Map.Entry<Integer, Integer>> itr = mp.entrySet().iterator();
    while(itr.hasNext()) {
    	Entry<Integer, Integer> en = itr.next();
    	System.out.println(en.getKey() + ": " + en.getValue());
    }
    sc.close();
	}

}
