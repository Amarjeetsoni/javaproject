package com.capgemini.util.lambda;

public class FindMaxImpl{

	public static void main(String[] args) {
	  Greater max = (a,b) -> {return(a>b?a:b);};
		System.out.println("maximum number is(15,20): " + max.findMax(154, 15));  
	}
}
