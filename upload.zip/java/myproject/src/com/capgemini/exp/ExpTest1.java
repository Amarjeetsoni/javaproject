package com.capgemini.exp;
import java.util.InputMismatchException;
import java.util.Scanner;
public class ExpTest1 {

	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        try {
	    System.out.print("Enter numerator: ");
	    int num = scan.nextInt();
	    System.out.print("Enter Denominator: ");
	    int den = scan.nextInt();
	    System.out.println("Quotient value: " + (num/den));
        }
        catch(ArithmeticException | InputMismatchException e) {
        	if(e instanceof ArithmeticException) {
        		System.out.println("Denominator can not be zero");
        	}
        	else if(e instanceof InputMismatchException) {
        		System.out.println("Integer unexpected");
        	}
        }
       /* catch(ArithmeticException exp1){
        	System.out.println("Denominator cannot devide by zero");  // approach message
        	System.out.println(exp1.getMessage());                    // read system message
        	exp1.printStackTrace();                                   // getmsg with exception and line number
        	
        }
        catch(Exception ex) {
        	System.out.println("Integer excepted");
//        	ex.printStackTrace();
        }*/
        finally {
	    System.out.println("End of program");
	}
        scan.close();
	}
 
}
