package com.capgemini.exp;
import java.util.Scanner;
public class ProductSeller {

	public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter Zone name: ");
    String str = scan.next();
    String s[] = {"north", "south", "east", "west", "ne", "sw"};
    try {
    	int count = 0;
    	for(String stri:s) {
    		if(stri.equalsIgnoreCase(str))
    		{
    			count++;
    			break;
    		}
    	}
    	if(count == 0)
    		throw new Exception(str + " not installed here");
    	else
    		System.out.println(str + " Zone founded");
    }
    catch(Exception e) {
    	System.out.println(e);
    }
    scan.close();

	}

}
