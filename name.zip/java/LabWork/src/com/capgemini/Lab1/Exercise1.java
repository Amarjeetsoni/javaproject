package com.capgemini.Lab1;
import java.util.Scanner;
public class Exercise1 {
    public static int calculateSum(int num) {
    	int sum = 0;
    	for(int i = 1; i <= num; i++) {
    		if(i % 3 == 0 || i % 5 == 0) {
    			sum += i;
    		}
    	}
    	return sum;
    }
	public static void main(String[] args) {
          Scanner scan = new Scanner(System.in);
          System.out.print("Enter a number: ");
          int number = scan.nextInt();
          int sum = calculateSum(number);
          System.out.println("Sum of number(divisible by 3 or 5): " + sum);
          scan.close();
	}

}
