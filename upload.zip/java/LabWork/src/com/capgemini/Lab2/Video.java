package com.capgemini.Lab2;

public class Video extends MediaItem {
   private String director;
   private String genre;
   private String yearOFrelease;
   
public Video() {
}
public Video(String identificationNumber, String title, int numberOfCopy, String runtime, String director, String genre, String yearOFrelease) {
	super(identificationNumber, title, numberOfCopy, runtime);
	this.director = director;
	this.genre = genre;
	this.yearOFrelease = yearOFrelease;
}
public String getDirector() {
	return director;
}
public void setDirector(String director) {
	this.director = director;
}
public String getGenre() {
	return genre;
}
public void setGenre(String genre) {
	this.genre = genre;
}
public String getYearOFrelease() {
	return yearOFrelease;
}
public void setYearOFrelease(String yearOFrelease) {
	this.yearOFrelease = yearOFrelease;
}
   
}
