package com.capgemini.io;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.util.StringTokenizer;

public class ReadingCommaSepFile {
 public static void main(String[] args) {
	try {
		FileInputStream fl = new FileInputStream("D:\\fileHandling\\filerecord.txt");
		DataInputStream name = new DataInputStream(fl);
		String record_string = "";
		int rec = 1;
		while((record_string = name.readLine()) != null)
		{
			StringTokenizer token = new StringTokenizer(record_string, ",");
			System.out.print("Rcord: " + (rec++));
			while(token.hasMoreTokens()) {
				System.out.println(token.nextToken());
			}
		}
	}catch(Exception e) {
		System.out.println(e);
	}
}
}
