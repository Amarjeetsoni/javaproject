import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ADDRGETNETWORKPARAMS } from 'dns';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  currentId: number;
  
  currentName: string;
  constructor(private formBuilder: FormBuilder,
  private router: Router, private userService: UserService,
private route:ActivatedRoute) {
  this.route.params.subscribe(params=>{
    this.currentId = params['id'];
  })
  console.log(this.currentId);
 }


  ngOnInit(): void {
    if(localStorage.username != null){
      this.editForm = this.formBuilder.group({
          id:[this.currentId],
          firstName: [{value:'',disabled:true}, [Validators.required, Validators.pattern("[A-Z][a-z]{2,14}")]],
          lastName: [{value:'', disabled:true}, Validators.required],
          age: ['', [Validators.required, Validators.min(20), Validators.max(30)]],
          mobileNumber: ['',[Validators.required, Validators.pattern("[6-9][0-9]{9}")]],
          email: ['',[ Validators.required, Validators.email]],
          password: ['', Validators.required]
      });
      this.userService.getUserById(this.currentId).subscribe(data=>{
        console.log(data);         
        this.editForm.setValue(data);
      },
    err=>{
      console.log(err.stk);
    })
    }
    else{
      this.router.navigate(['/login']);
    }
  }
  logOutUser(){
    if(localStorage.username != null){
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }

  updateUser(){
    this.submitted = true;
    if(this.editForm.invalid){
      return;
    }
    // on success full validation exicute below code
    console.log(this.editForm.value);
    this.userService.updateUserById(this.editForm.getRawValue()).subscribe(data=>{
      alert(`${this.editForm.controls.firstName.value} record is updated successfully..!`);
      this.router.navigate(['list-user']);
    },
  err=>{
   console.log(err.stack);
  });   
  }
}
