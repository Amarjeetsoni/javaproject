package com.cg.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.WalletAccountBean;
import com.cg.bean.WalletMoneyStatement;
import com.cg.repo.Details;

class delay extends Thread {
	public void run() {
      try {
		sleep(1000);
	} catch (InterruptedException e) {
		e.printStackTrace();
	}       		
 	}
}
public class CreateAccountImplement implements CreateAccount {

	
	@Override
	public void createAccount() throws IOException {
		WalletAccountBean wb;
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		System.out.println("\t\t*************Welcome To Create Acoount Page***************\n\n(*) fields are mandatory to fill\n");
		System.out.print("Enter FirstName*: ");
		String first_name = bf.readLine();
		System.out.print("Enter MiddleName: ");
		String middle_name = bf.readLine();
		System.out.print("Enter LastName*: ");
		String last_name = bf.readLine();
		System.out.print("Enter Date of Birth(DD/MM/YYYY)*: ");
		String dob = bf.readLine();
		System.out.print("Enter Age: ");
		int age = Integer.parseInt(bf.readLine());
		System.out.print("Enter MobileNo*: ");
		String mobileNum = bf.readLine();
		System.out.print("Enter emailID*: ");
		String email = bf.readLine();
		String user_name = null;
		String pass;
		System.out.println("\n\t\t\t:::Detail Varifying:::");
		new delay().run();
		Details d = new Details();
		if(d.varifyAccountDetails(email, mobileNum)) {
			System.out.print("Details varified\n\n");
			System.out.println("Now Choose a user Name:\n===> Press 1 for Manual Enter\n===> Press 2 from suggestions\nChoose: ");
			int num = sc.nextInt();
			if(num == 1) {
				System.out.print("Enter User Name: ");
				user_name = sc.next();
				while(d.check_name(user_name) == false) {
					System.out.println("UserName already exist Try for another..");
					System.out.print("Enter User Name: ");
					user_name = sc.next();
				}
				System.out.print("User_name varified...\nChoose a Password(minimum of 8 charater): ");
				pass = sc.next();
				while(pass.length() < 8) {
					System.out.print("password Length is less then 8 charaters try again..\n\\nChoose a Password(minimum of 8 charater): ");
					pass = sc.next();
				}
				
				wb = new WalletAccountBean(first_name, middle_name,last_name,dob, age, mobileNum, email, user_name, pass, 0);
				d.addAccount(wb);
				WalletMoneyStatement acc = new WalletMoneyStatement(user_name, pass, "Acoount Created..");
				d.addStatement(acc);
				System.out.println("Account successfully Created...");
			}
			else if(num == 2) {
				List<String> str = new ArrayList<String>();
				String str1 = (first_name) + "_" + (last_name) + mobileNum.substring(mobileNum.length()-4);
				String str2 = (first_name) +  "_" + mobileNum.substring(mobileNum.length()-4);
				String str3 = (first_name) +  "_" + mobileNum.substring(mobileNum.length()-5) + last_name;
				if(d.checkUserName(str1)) {
					str.add(str1);
				}
				if(d.checkUserName(str2)) {
					str.add(str2);
				}
				if(d.checkUserName(str3)) {
					str.add(str3);
				}
				if(str.size() == 0) {
					System.out.println("NO Suggestion available.. Enter manuualy\n");
					System.out.print("Enter User Name: ");
					user_name = sc.next();
					while(d.check_name(user_name) == false) {
						System.out.println("UserName already exist Try for another..");
						System.out.print("Enter User Name: ");
						user_name = sc.next();
					}
				}
				else {
					System.out.println(str);
					System.out.print("Select any One of them: ");
					int check = sc.nextInt();
					if(check < str.size()) {
						user_name = str.get(check-1);
					}
				}
				System.out.print("User_name varified...\nChoose a Password(minimum of 8 charater): ");
				pass = sc.next();
				while(pass.length() < 8) {
					System.out.print("password Length is less then 8 charaters try again..\n\nChoose a Password(minimum of 8 charater): ");
					pass = sc.next();
				}
				
				wb = new WalletAccountBean(first_name, middle_name,last_name,dob, age, mobileNum, email, user_name, pass, 0);
				d.addAccount(wb);
				WalletMoneyStatement acc = new WalletMoneyStatement(user_name, pass, "Acoount Created..");
				d.addStatement(acc);
				System.out.println("Account successfully Created...");
			}
			else {
				 System.out.println("Invalid Entery...");
				 
			}
		}
		else
		{
			System.out.print("EmailId/MobileNumber already exist or not valid, Try to login...");
		}
//		sc.close();
	}

}
