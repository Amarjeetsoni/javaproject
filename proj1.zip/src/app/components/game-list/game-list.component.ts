import { Component, OnInit } from '@angular/core';
import { GameService } from '../../services/game.service';
import { Game } from '../../models/game.model';

@Component({
  selector: 'app-game-list',
  templateUrl: './game-list.component.html',
  styleUrls: ['./game-list.component.css']
})
export class GameListComponent implements OnInit {

  games: Game[];
  currentBalance: number;
  constructor(private gameService: GameService) { }

  ngOnInit() {
    this.currentBalance = this.gameService.getBalance();
    this.gameService.gameGameList().subscribe(data=>{
            this.games = data;
    },
  err=>{
    console.log(err.stack);
  })
  }
  deductAmount(amount: number){
    
    this.currentBalance -= amount;
    if(this.currentBalance >= 0)
    {
      alert(`money ${amount} deducted from your account`);
    }
    else{
      this.currentBalance += amount;
      alert(`Not Enough balance`);
    }
  }
}
