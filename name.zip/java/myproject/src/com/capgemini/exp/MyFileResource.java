package com.capgemini.exp;

public class MyFileResource implements AutoCloseable{
 private boolean flag = false;
 public void openfile() {
	 flag = true;
 }
 public void doTask() {
	 if(flag == true) {
		 System.out.println("Task Started");
	 }
	 else
		 System.out.println("Open file first");
 }
 public void closeFile() {
	 flag = false;
	 System.out.println("File Closed");
 }
 public void close() throws Exception{
	 closeFile();
 }
}
