package com.capgemini.example;

public abstract class Item {
    protected int identificationNumber;
    protected String Title;
    protected int numberOfCopy;
    
    
	public Item(int identificationNumber, String title, int numberOfCopy) {
		this.identificationNumber = identificationNumber;
		Title = title;
		this.numberOfCopy = numberOfCopy;
	}
	public int getIdentificationNumber() {
		return identificationNumber;
	}
	public void setIdentificationNumber(int identificationNumber) {
		this.identificationNumber = identificationNumber;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public int getNumberOfCopy() {
		return numberOfCopy;
	}
	public void setNumberOfCopy(int numberOfCopy) {
		this.numberOfCopy = numberOfCopy;
	}
    public String toString() {
    	return ("The values are: " + identificationNumber + " " + Title + " " + numberOfCopy);
    }
    public void print() {
    	System.out.println("identification number: " + identificationNumber + "\ntitle: " + Title + "\nnumber of copy: " + numberOfCopy);
    }
    
}
