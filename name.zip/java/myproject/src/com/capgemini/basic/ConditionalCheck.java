package com.capgemini.basic;

public class ConditionalCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            System.out.println((Integer.parseInt(args[0]) % 2 == 0)?"Even" : "Odd");
            
	}

}
