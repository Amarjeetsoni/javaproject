package com.capgemini.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Iterator;
public class Lab7Question2 {
    public static Map<Character, Integer> countCharacter(char str[]){
    	Map<Character, Integer> mp = new TreeMap<>();
    	
    	for(int i = 0; i < str.length; i++) {
    		if(mp.containsKey(str[i]))
    		mp.put(str[i], mp.get(str[i])+1);
    		else
    		mp.put(str[i], 1);
    	}
    	return mp;
    }
	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	String s = scan.nextLine();
	char str[] = s.toCharArray();
	
	Map<Character, Integer> mp = new HashMap<>();
	mp = countCharacter(str);
	Iterator<Map.Entry<Character, Integer>> it = mp.entrySet().iterator();
	while(it.hasNext()){
		Entry<Character, Integer> num = it.next();
		System.out.println(num.getKey() + "  " + num.getValue());
	}
	scan.close();
}
}
