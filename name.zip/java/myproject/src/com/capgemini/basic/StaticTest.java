package com.capgemini.basic;

public class StaticTest {
   static int n = 5;
	static {
		System.out.println("Block loaded");
		System.out.println("Value: " + n);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println("Main function is loded");  
	StaticTest t = new StaticTest();
//	StaticTest t1 = new StaticTest();
	}
	static 
	{
		System.out.println("Block 2 is loaded");
	}
	{
		System.out.println("General block ready");
	}
	{
		System.out.println("General block2 ready");
	}

}
