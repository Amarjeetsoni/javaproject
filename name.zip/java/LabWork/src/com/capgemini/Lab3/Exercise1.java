package com.capgemini.Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise1 {
	public static int getSecondSmallest(int arr[]) {
		Arrays.sort(arr);
		return arr[1];
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number of elemets in an array: ");
		int size = sc.nextInt();
		int arr[] = new int[size];
		System.out.print("Enter elements: ");
		for(int i = 0; i < size; i++) {
			arr[i] = sc.nextInt();
		}
		System.out.println("second Smallest number is: " + getSecondSmallest(arr));
		sc.close();
	}

}
