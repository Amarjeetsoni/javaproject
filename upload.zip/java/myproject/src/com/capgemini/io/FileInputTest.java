package com.capgemini.io;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;

public class FileInputTest {

	public static void main(String[] args) {
        try (FileInputStream fileIn = new FileInputStream("D:\\\\fileHandling\\\\write.txt");
        		BufferedInputStream buffer = new BufferedInputStream(fileIn)){
        	DataInputStream din = new DataInputStream(buffer);
        	String line;
        	while((line = din.readLine()) != null) {
        		System.out.println(line);
        	}
//        	FileInputStream fileIn = new FileInputStream("D:\\fileHandling\\first.txt");
//        	int ch;
//        	while((ch = fileIn.read()) != -1) {
//        		System.out.print((char)ch);
//        	}
        	fileIn.close();
        	buffer.close();
        	
        }catch(Exception e) {
        	System.out.println(e);
        }
        
	}

}
