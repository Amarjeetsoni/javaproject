
public class Diffrence {
public static void main(String[] args) {
	   
}
}
