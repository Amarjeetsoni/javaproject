package com.cg.eis.exception;
import java.util.Scanner;
public class EmployeeException {
    public static void check(int sal) throws EmployeeExp{
    	if(sal < 3000)
    		throw new EmployeeExp("salary is below 3000");
    	else
    		System.out.println("Salary is above 3000");
    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter salary: ");
		int sal = sc.nextInt();
		try {
			check(sal);
		}catch(Exception e) {
			System.out.println(e);
		}
		sc.close();

	}

}
