package com.capgemini.Lab6;

import java.util.Scanner;

public class Exercise9 {
   public static void calculateDiffrence(int date, int month, int year) {
	   int cD = 18, cM = 01, cY = 2020;
	   int []arr = new int[]{31,28,31,30,31,30,31,31,30,31,30,31};
	   if(year % 4 == 0) {
		   arr[1] = 29;
	   }
	   int dD = cD - date;
	   int dM = cM - month;
	   int dY = cY - year;
	   if(dY < 0) {
		   System.out.println("You have Enterd into future");
	   }
	   if(dD < 0) {
		   if(dM < 0) {
			 dM += 11;
			 dY -= 1;
			 dD += arr[dM-1];
		   }else {
			   dD += arr[dM-1];
			   dM -= 1;
		   }
	   }
	   if(dM < 0) {
		   dM += 12;
		   dY -=  1;
	   }
	   System.out.println("Diffrence\nYear: " + dY + " Month: " + dM + " Days: " + dD);
   }
   public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter Date(DD/MM/YYYU): ");
	int date = sc.nextInt();
	int month = sc.nextInt();
	int year = sc.nextInt();
	calculateDiffrence(date,month,year);
	sc.close();
}
}
