import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  // javascript object
  // custDetails = {
  //   name: 'Amarjeet',
  //   age: 22,
  //   address: {
  //     city: 'Lucknow',
  //     state: 'Uttar Pradesh'
  //   }
  // }
  
  // array data
  // months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

   // creating form group object
  loginForm: FormGroup;
   submitted: boolean = false;
  // Constructor Dependency Injuction
  // Dependency Injuction makes your applictaion loosely typed
  // so that application can be easly maintained
  // formbuilder to built form elements with default values and validations
  // router service to navigate programmatically from componets to other
  constructor(private formBuilder: FormBuilder, private router: Router) { 
   
  }

  // Life Cycle Hook(after constructor it will call to intialized the form)
  ngOnInit(): void {
  this.loginForm = this.formBuilder.group({
   email:['', Validators.required],
   password:['',Validators.required]
  });
  }
  
  verifyLogin(){
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }

    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;
    if(username == "amar@gmail.com" && password == "amar") {
      localStorage.username = username;
      sessionStorage.username = username;
      this.router.navigate(['list-user']);
    }
    else{
      this.invalidLogin = true;
    }
  }
// end of cerifyLogin() function
  invalidLogin:boolean = false;
}
