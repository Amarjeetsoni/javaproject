package com.capgemini.inheritance;

public class BankAcoountValidation extends IDValidator {

	@Override
	public boolean validation() {
		// TODO Auto-generated method stub
		String str = getID();
		String substr = str.substring(0, 4);
//		System.out.println(substr);
//		System.out.println(str.length());
		if(substr.equals("PNQB") && str.length() == 16)
			return true;
		return false;
	}
	public static void main(String[] args) {
		BankAcoountValidation ac1 = new BankAcoountValidation();
		ac1.setID("PNQB123456789123");
		System.out.println(ac1.validation()?"Valid account Number":"Invalid account number");
	}

}
