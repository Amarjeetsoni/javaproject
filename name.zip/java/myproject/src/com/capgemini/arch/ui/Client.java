package com.capgemini.arch.ui;

import com.capgemini.arch.bean.EmployeeBean;
import com.capgemini.arch.service.EmployeeServiceImp;

public class Client {

	public static void main(String[] args) {
      EmployeeServiceImp service = new EmployeeServiceImp();
      service.addEmployee(new EmployeeBean(1011, "Sunny", "Manager", 65000));
      service.addEmployee(new EmployeeBean(1012, "Amar", "Executive", 50000));
      service.addEmployee(new EmployeeBean(1013, "Ankit", "Marketing", 55000));
      service.addEmployee(new EmployeeBean(1014, "Vikram", "Software", 35000));
      System.out.println(service.findByID(1012));
      System.out.println(service.getEmployees());
	}

}
