package com.capgemini.Lab10.StreamAPI;

import java.time.LocalDate;

public class Employee extends Department {
   protected int employeeId;
   protected double salary;
   protected String firstName, lastName, email, phoneNumber,desigantion;
   LocalDate hireDate;
   Department depart;

 public Employee() {
	 
 }
 public Employee(int employeeId, double salary,String firstName, String lastName, String email, String phoneNumber, String desigantion, LocalDate hireDate,
		Department depart) {
	super();
	this.employeeId = employeeId;
	this.salary = salary;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.phoneNumber = phoneNumber;
	this.desigantion = desigantion;
	this.hireDate = hireDate;
	this.depart = depart;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getDesigantion() {
	return desigantion;
}
public void setDesigantion(String desigantion) {
	this.desigantion = desigantion;
}
public LocalDate getHireDate() {
	return hireDate;
}
public void setHireDate(LocalDate hireDate) {
	this.hireDate = hireDate;
}
public Department getDepart() {
	return depart;
}
public void setDepart(Department depart) {
	this.depart = depart;
}
@Override
public String toString() {
	return "employeeId= " + employeeId + ", salary= " + salary + ", firstName=" + firstName + ", lastName="
			+ lastName + ", email=" + email + ", phoneNumber=" + phoneNumber + ", desigantion=" + desigantion
			+ ", hireDate=" + hireDate;
}
   
   
}
