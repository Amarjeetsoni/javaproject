package com.capgemini.Lab5;

import java.util.Scanner;

public class Exercise1 {
   public static void main(String[] args) {
	   Scanner scan = new Scanner(System.in);
	   System.out.print("**********Traffic Light Control*********\n1. * RED\n2. * YELLOW\n3. * GREEN\n");
	   System.out.print("Enter choise: ");
	   int num = scan.nextInt();
	   if(num == 1)
		   System.out.println("STOP");
	   else if(num == 2)
		   System.out.println("Ready");
	   else if(num == 3)
		   System.out.println("Go");
	   scan.close();
	   
}
   
}
