package com.capgemini.Lab10.StreamAPI;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;


public class EmployeeService {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	EmployeeRepository empRep = new EmployeeRepository();
	Department d1 = new Department(123, 116019, "Sales");
	empRep.addDepartment(d1);
	empRep.addEmployee(new Employee(1005, 25000.00, "Aman", "Kumar", "amankumar058@gmail.com", "1122334488", "Advisor", LocalDate.parse("2018-05-20"), d1));
	empRep.addEmployee(new Employee(1008, 20000.00, "Ankit", "Kumar", "ankitkumar1569@gmail.com", "2244668811", "Consultant", LocalDate.parse("2010-12-21"), d1));
	empRep.addEmployee(new Employee(1009, 22000.00, "Sumit", "Shyam", "sumitsh159@gmail.com", "1563212536", "Advisor", LocalDate.parse("2019-05-18"), d1));
	empRep.addEmployee(new Employee(1011, 21000.00, "Pravesh", "Malik", "praveshmalik148@gmail.com", "9025698745", "HR", LocalDate.parse("2014-12-12"), d1));
	empRep.addEmployee(new Employee(1015, 18000.00, "Pranav", "kumar", "pranavkumar125@gmail.com", "9056142365", "Head", LocalDate.parse("2005-05-20"), d1));
	
    d1 = new Department(150, 116025, "IT");
    empRep.addDepartment(d1);
    empRep.addEmployee(new Employee(1019, 35000.00, "Krishan", "Kumar", "krishankumar788@gmail.com", "112233499", "Advisor", LocalDate.parse("2018-04-20"), d1));
	empRep.addEmployee(new Employee(1089, 50000.00, "Arun", "Singh", "arunsingh1569@gmail.com", "2244665611", "Consultant", LocalDate.parse("2012-12-21"), d1));
	empRep.addEmployee(new Employee(1098, 32000.00, "Hari", "Shyam", "HS489@gmail.com", "11236212536", "Advisor", LocalDate.parse("2009-12-18"), d1));
	empRep.addEmployee(new Employee(1031, 45000.00, "Abhishek", "", "abhishek148@gmail.com", "90256454545", "HR", LocalDate.parse("2014-01-10"), d1));
	empRep.addEmployee(new Employee(1028, 50000.00, "Rishab", "Singh", "rishabs115@gmail.com", "9056112356", "Marketing", LocalDate.parse("2009-09-20"), d1));
    
	d1 = new Department(150, 116025, "Developer");
	empRep.addDepartment(d1);
	empRep.addEmployee(new Employee(1031, 45000.00, "Abhishek", "", "abhishek148@gmail.com", "90256454545", "HR", LocalDate.parse("2001-01-10"), d1));
	empRep.addEmployee(new Employee(1028, 50000.00, "Rishab", "Singh", "rishabs115@gmail.com", "9056112356", "Marketing", LocalDate.parse("2009-09-20"), d1));
	
	d1 = new Department(0,0,"");
	empRep.addDepartment(d1);
	empRep.addEmployee(new Employee(1028, 50000.00, "Akshat", "Yadav", "Akshatyadev235@gmail.com", "9076112356", "Marketing", LocalDate.parse("2009-09-20"), d1));
	empRep.addEmployee(new Employee(1028, 50000.00, "Pritam", "Singh", "pritam1225@gmail.com", "9056115456", "Sales", LocalDate.parse("2009-09-20"), d1));
	
	d1 = new Department(136,116012,"Founder");
	empRep.addDepartment(d1);
	// part 1
	double totalSal = empRep.record.stream().map(e->e.getSalary()).reduce(0.0, Double::sum);
	System.out.println("Total Salary: " + totalSal);
	
	// part 2
	System.out.println("\n\n:::Number of departments along with their number of employees::");
	empRep.record.stream().filter(e->e.depart.getDepartmentName().length()!=0).map(e->e.depart.getDepartmentName()).distinct().forEach(e->System.out.println(e + "  " + empRep.record.stream().filter(g->g.depart.getDepartmentName().equals(e)).count()));

    // part 3
	System.out.println("\n\n::Employee who is senior of them:::");
	Optional<String> str= empRep.record.stream().map(e->e.getHireDate().toString()).reduce((x,y)->(x.compareTo(y)<0)?x:y);
    String str1 = str.get();
    empRep.record.stream().filter(e->e.getHireDate().toString().equals(str1)).forEach(e->System.out.println(e));
    
    // part 4
    System.out.println("\n\nDuration of Work of Each employee: ");
    empRep.record.stream().forEach(e->System.out.println(e.getFirstName() + " " + e.getLastName() + " " + ChronoUnit.MONTHS.between(e.getHireDate(), LocalDate.now()) + " Months" + " " + ChronoUnit.DAYS.between(e.getHireDate(), LocalDate.now())%30 + " Days"));
    
    // part 5
    System.out.println("\n\nEmployees without departments: ");
    empRep.record.stream().filter(e->e.depart.getDepartmentName().length() == 0).forEach(e->System.out.println(e));
    
    // part 6
    System.out.println("\n\nDepartments without employees: ");
    
    // part 7
    System.out.println("\n\ndepartment with highest count of employee: ");
    empRep.record.stream().map(e->e.)
  }
}
