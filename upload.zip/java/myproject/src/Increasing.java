
public class Increasing {
  public static boolean check(int num) {
	  if(num / 10 == 0)
		  return true;
	  int num1 = num%10;
	  num /= 10;
	  if(num1 <= num%10)
		  return false;
	  return check(num);
  }
	public static void main(String[] args) {
	for(int i = 1000; i <= 9999; i++) {
		if(check(i)) {
			System.out.println(i);
		}
	}
}
  
}
