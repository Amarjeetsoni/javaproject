package com.capgemini.util.lambda;

import java.io.File;
import java.io.FileFilter;

public class FileWithLambda {

	public static void main(String[] args) {
       FileFilter filter = (File pathname) -> pathname.getName().endsWith(".txt");
       File dir = new File("D:\\java");
       File[] contents = dir.listFiles(filter);
       System.out.println("Extention as .txt");
       for(File file:contents) {
    	   System.out.println(file);
       }
       System.out.println("List of Content in the folder: ");
       String[] lists = dir.list();
       for(String f: lists) {
    	   System.out.println(f);
       }
	}

}
