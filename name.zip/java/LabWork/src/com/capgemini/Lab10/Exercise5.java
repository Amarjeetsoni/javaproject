package com.capgemini.Lab10;

import java.util.Scanner;

interface Fact{
	int calculate(int num);
}
public class Exercise5 {
   public int factorial(int num) {
	   int num1 = 1;
	   for(int i = 1; i <= num; i++) {
		   num1 *= i;
	   }
	   return num1;
   }
   public static void main(String[] args) {
	Exercise5 exp = new Exercise5();
	Fact find = exp::factorial;
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter a number: ");
	int num1 = sc.nextInt();
	System.out.println(find.calculate(num1));
	sc.close();
}
}
