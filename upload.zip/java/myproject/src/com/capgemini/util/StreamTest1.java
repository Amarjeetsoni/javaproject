package com.capgemini.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamTest1 {
   public static void main(String[] args) {
	List<Integer> lst = Arrays.asList(10,20,30,50,40);
	lst.stream().forEach(i->System.out.println(i));
	
	// reuse with stream
  Stream<Integer> strm = Stream.of(10,20,30,50,40);     // group of values is converted into stream
//  strm.forEach(System.out::println);   // traverse all over the stream
  
  strm.map(i->i>10).forEach(n->System.out.println(n));   // to find the values are greater then 10
  Stream<String> nameStream = Stream.of("Ajay", "hina", "AMAR", "jk", "aman", "ankit");
  List<String> name = Arrays.asList("Ajay", "hina", "AMAR", "jk", "aman", "ankit");
  nameStream.map(str->str.length()>4).forEach(str->System.out.println(str));
  name.stream().map(str->str.length()).forEach(str->System.out.println(str));
  name.stream().map(str->str.toUpperCase()).forEach(str->System.out.println(str));
  
  //  convert stream to list
  nameStream = Stream.of("Ajay", "hina", "AMAR", "jk", "aman", "ankit");
  List<String> lst1 = nameStream.map(str->str.toUpperCase()).collect(Collectors.toList());
  nameStream = Stream.of("Ajay", "hina", "amar", "jk", "Amar");
  System.out.println(lst1);
//  lst1 = nameStream.limit(3).map(str->str.toUpperCase()).collect(Collectors.toList());
  lst1 = nameStream.map(str->str.toUpperCase()).distinct().collect(Collectors.toList());
  System.out.println(lst1);
   
   }
}
