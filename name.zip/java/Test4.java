public class Test4{
  public static void main(String args[])
{
   String num = new String("40");
   int a = Integer.parseInt(num);
   int b = Integer.parseInt(args[1]);
   System.out.println(a+b);
   System.out.println("Sum is: " + a+b);
   System.out.println("Sum is: " + (a+b));
}
}