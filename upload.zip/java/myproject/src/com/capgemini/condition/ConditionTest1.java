package com.capgemini.condition;

public class ConditionTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int num = Integer.parseInt(args[0]);
       if(num > 10) {
    	   System.out.println("Valid number");
       }
       else
       {
    	   System.out.println("Number is not a valid number");
       }
       System.out.println("End of program....");
	}

}
