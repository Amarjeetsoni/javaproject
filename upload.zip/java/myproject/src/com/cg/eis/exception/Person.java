package com.cg.eis.exception;
import java.util.Scanner;
public class Person {
	public static void check(int age) throws Exception {
		if(age < 15)
			throw new Exception("the person is below 15");
		else
			System.out.println("person is above 15");
	}
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enetr age: ");
		int age = scan.nextInt();
		try {
			check(age);
		}catch(Exception e) {
			System.out.println(e);
		}
		scan.close();
	}

}
