package com.capgemini.util.lambda;

import java.util.HashSet;
import java.util.function.Predicate;

public class PridicateTest {

	public static void main(String[] args) {
		HashSet<Employee> emps = new HashSet<>();
		emps.add(new Employee(101, "Amar", 45000, "A"));
		emps.add(new Employee(102, "Satyam", 40000, "A"));
		emps.add(new Employee(104, "Shubham", 50000, "B"));
		emps.add(new Employee(105, "Anuj", 49000, "C"));
		emps.add(new Employee(108, "Venu", 51000, "D"));
		
		Predicate<Employee> cond1 = e1->e1.getSalary()>=30000 && e1.getSalary()<=45000;
		Predicate<Employee> cond2 = e1->e1.getName().contains("a");
		emps.stream().filter(cond1).forEach(e->System.out.println(e.getId() + " " + e.getName()));
		System.out.println();
		emps.stream().filter(cond2).forEach(e->System.out.println(e.getId() + " " + e.getName()));
        System.out.println("by using condition::");
		getData(emps, cond1);
		getData(emps,cond2);
	}
	public static void getData(java.util.Set<Employee> em,Predicate<Employee> p) {
		em.stream().filter(p).forEach(e->System.out.println(e.getId() + " " + e.getName()));
	}

}
