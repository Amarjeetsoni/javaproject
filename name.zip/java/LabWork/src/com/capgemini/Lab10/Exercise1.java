package com.capgemini.Lab10;

import java.util.Scanner;

interface Square{
	int square(int a, int b);
}
public class Exercise1 {
  public static void main(String[] args) {
	Square sq = (a,b)->{
		int num = 1;
		for(int i = 1; i <= b; i++) {
		num = num*a;
	}
	return num;};
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter value of a and b: ");
	int a = sc.nextInt();
	int b = sc.nextInt();
    System.out.println("Square of number: " + sq.square(a,b));
    sc.close();
}
}
