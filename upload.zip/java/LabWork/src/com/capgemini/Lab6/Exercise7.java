package com.capgemini.Lab6;

import java.io.File;
import java.util.Scanner;

public class Exercise7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter file name: ");
		String str = sc.nextLine();
		File myfile = new File("D:\\fileHandling", str);
		if(myfile.exists()) {
			System.out.println("File Founded!!");
			if(myfile.canRead()) {
				System.out.println("File is readable!!");
			}else
				System.out.println("file is Not Readable...");
			if(myfile.canWrite()) {
				System.out.println("File is writeable!!");
			}else {
				System.out.println("file is not Writable...");
			}
			if(myfile.isFile()) {
				System.out.println("It is a type of file");
			}else {
				System.out.println("it is a type of direactory");
			}
			System.out.println("size OF file is" + myfile.length());
		}else
		{
			System.out.println("File Does not exist");
		}
		sc.close();
		

	}

}
