package com.capgemini.Lab2;

public abstract class Item {
      private String identificationNumber;
      private String title;
      private int numberOfCopy;
      public Item() {
    	  
      }
	public Item(String identificationNumber, String title, int numberOfCopy) {
		this.identificationNumber = identificationNumber;
		this.title = title;
		this.numberOfCopy = numberOfCopy;
	}
	public String getIdentificationNumber() {
		return identificationNumber;
	}
	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNumberOfCopy() {
		return numberOfCopy;
	}
	public void setNumberOfCopy(int numberOfCopy) {
		this.numberOfCopy = numberOfCopy;
	}
	
	@Override
	public String toString() {
		return "Item [identificationNumber=" + identificationNumber + ", title=" + title + ", numberOfCopy="
				+ numberOfCopy + "]";
	}
     abstract void print();
     abstract void checkIn(String time);
     abstract void checkOut(String time);
     
}
