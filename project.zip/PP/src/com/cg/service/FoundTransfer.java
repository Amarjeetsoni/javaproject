package com.cg.service;

public interface FoundTransfer {
    void foundTransferAmount(String user1, String pass, String user2, double bal);
}
