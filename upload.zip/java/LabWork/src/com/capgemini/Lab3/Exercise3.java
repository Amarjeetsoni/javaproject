package com.capgemini.Lab3;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise3 {
    public static int Reverse(int num) {
    	String str = Integer.toString(num);
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb = sb.reverse();
        str = sb.toString();
        num = Integer.parseInt(str);
        return num;
        
    }
    public static int[] getShoted(int arr[]){
    	for(int i = 0; i < arr.length; i++) {
    		arr[i] = Reverse(arr[i]);
    	}
    	
    	Arrays.sort(arr);
    	return arr;
    }
    
    public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter Number of elemets: ");
		int size = scan.nextInt();
		System.out.print("Enter Elemets: ");
		int []arr = new int[size];
		for(int i = 0; i < size; i++) {
			arr[i] = scan.nextInt();
		}
		arr = getShoted(arr);
		System.out.println("After reversing and sorting");
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		scan.close();
	}
}
