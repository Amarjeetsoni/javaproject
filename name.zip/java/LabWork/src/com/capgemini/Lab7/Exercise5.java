package com.capgemini.Lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Exercise5 {
	public static int getSecondSmallest(int arr[]) {
		   List<Integer> li = new ArrayList<>();
		   for(int i = 0; i < arr.length; i++) {
			   li.add(arr[i]);
		   }
		   Collections.sort(li);
		   Set<Integer> st = new HashSet<>(li);
		   Iterator<Integer> itr = st.iterator();
		   itr.next();
		   return itr.next();
	   }
		public static void main(String[] args) {
	       Scanner sc = new Scanner(System.in);
	       System.out.println("Enter size of array: ");
	       int size = sc.nextInt();
	       int arr[] = new int[size];
	       System.out.println("Enter elemets: ");
	       for(int i = 0; i < size; i++) {
	    	   arr[i] = sc.nextInt();
	       }
	       System.out.println("The 2nd Lowest: " + getSecondSmallest(arr));
	       sc.close();
	    		   
		}
}
