package com.capgemini.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SalesImp {
     public static void main(String[] args) {
//		new SalesPerson().start();
    	 ExecutorService execute = Executors.newCachedThreadPool();
    	 execute.execute(new SalesPerson());
    	 execute.execute(new Days());
    	 execute.shutdown();
	}
}
