package com.capgemini.condition;
import java.util.Scanner;
public class ConditionTest4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***************This is Mini calculator******************");
		System.out.print("Enter the first number: ");
		Scanner scan = new Scanner(System.in);
		int num1 = scan.nextInt();
		System.out.print("Enter second number: ");
		int num2 = scan.nextInt();
        System.out.println("Select Your choise: ");
        System.out.println("1. ADD \n2. SUB\n3. DIVIDE\n4. MULTIPLY\n5.Modulo\nSelect Your Choise: ");
        String ch = scan.next();
        double num = 0;
        int count = 0;
        switch(ch) {
        case "+":
        	num = num1 + num2;
        	break;
        case "-":
        	num = num1 + num2;
        	break;
        case "*":
        	num = num1 * num2;
        	break;
        case "/":
        	num = num1 / num2;
        	break;
        case "%":
        	num = num1 % num2;
        	break;
        default:
           num = 0;
           count = 1;
           System.out.println("Choise is wrong");		
        }
        if(count == 0)
        {
        	System.out.println("Output is: " + num);
        }
	}

}
