package com.capgemini.Lab8;
import java.io.FileReader;
import java.io.FileWriter;

public class FileProgram{
    
	public static void main(String[] args) {
		try {
			FileReader fo = new FileReader("D:\\fileHandling\\first.txt");
			FileWriter fw = new FileWriter("D:\\fileHandling\\cpp.txt");
		    new copyDataThread(fo, fw).start();
		    
		}catch(Exception e){
			System.out.println(e);
		}
	}
}
