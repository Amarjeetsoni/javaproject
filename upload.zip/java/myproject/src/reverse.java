import java.util.Scanner;

public class reverse {
    public static int number = 0;
	public static int value(int num) {
	   if(num / 10 == 0) {
		   number = number*10 + num;
		   return number;
	   }
	   number = number*10 + num%10;
	   num /= 10;
	   return value(num);
   }
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int number1 = sc.nextInt();
	int reverse = value(number1);
	System.out.println();
	System.out.println("Reverse of number: " + reverse);
	System.out.println((reverse==number1)?"the number is palendrome":"not a palendrom");
	sc.close();
}
}
