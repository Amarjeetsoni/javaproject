import { Component, OnInit } from '@angular/core';
import { CalculatorService } from '../../services/calculator.service';
import { User } from '../../models/user.model';
import { UserService } from '../../services/user.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
  
  // searchText = "Amit";
  searchText:any;
  // to handle List of Users
   users: User[];
  // injection UserServices which is using httpClient services
  constructor(private userService: UserService, private router:Router){}
  ngOnInit(): void {
    if(localStorage.username!=null){
      this.userService.getAllUsers().subscribe(data=>{
        // on resolve or on success
        this.users = data;
        console.log(this.users);
      },
    err=>{
     // on reject or on error
     console.log(err.stack);
    })
    }
    else{
          this.router.navigate(['/login']);
    }
}
// logout session
logOutUser(){
  if(localStorage.username != null){
    localStorage.removeItem("username");
    this.router.navigate(['/login']);
  }
}
addUser(){
  this.router.navigate(['add-user']);
}

editUser(user: User){
  this.router.navigate(['edit-user', user.id]);
}

deleteUser(user: User):void{
  let result = confirm(`Do You wnat to delete user ${user.firstName} details?`);
  if(result){
    this.userService.deleteUserById(user.id).subscribe(data=>{
     this.users = this.users.filter(u=>u!==user);
    },
  err=>{
   console.log(err.stack);
  });
  alert(`${user.firstName} record is deleted...!`);
  }
}
}
  // understanding Calc service
  // Injecting calculator Services
  // sum: number;
  // product: number;
  // constructor(private calculatorService: CalculatorService) { }

  // ngOnInit(){
  //   this.sum = this.calculatorService.addition(100,200);
  //   this.product = this.calculatorService.multiplication(100,200);
  // }


