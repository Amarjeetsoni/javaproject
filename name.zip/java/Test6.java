public class Test6{
  public static void main(String args[]){
    String s1 = "Initial";
    String s2 = "initial";
   // s2 = "Initial";
   System.out.println(s1 + " " + s1.hashCode());
   System.out.println(s2 + " " + s2.hashCode());
   String str = new String("Apple");   // not advised to this type of initilized
   System.out.println(str + " Value " + str.hashCode());
   
   
}
}