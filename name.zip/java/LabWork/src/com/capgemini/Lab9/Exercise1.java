package com.capgemini.Lab9;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Days extends Thread{
	String person[] = {"Monday", "Tuesday", "Wednesday", "Thrusday", "Friday", "Saturday", "Sunday"};
	public void run() {
    	try{for(String str: person) {
    		System.out.print(str + " ");	
    		sleep(450);
    	}
    	}catch(Exception e) {
    	System.out.println(e);
    }
}
}
class SalesPerson extends Thread{
	String person[] = {"amar", "ankit", "saurav", "Pritam", "avinash"};
	public void run() {
//		new Days().start();
    	try {
    		for(String str: person) {
    		System.out.print("\n" + str + ": ");
    		sleep(500);
    	}
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
}
public class Exercise1 {
	 public static void main(String[] args) {
//			new SalesPerson().start();
	    	 ExecutorService execute = Executors.newCachedThreadPool();
	    	 execute.execute(new SalesPerson());
	    	 execute.execute(new Days());
	    	 execute.shutdown();
		}
}
