package com.capgemini.example;

public class JournalPaper extends WrittenItem {
      private int yearOfPublication;
      
	public JournalPaper(int identificationNumber, String title, int numberOfCopy, String author, int yearPublication) {
		super(identificationNumber, title, numberOfCopy, author);
	    this.yearOfPublication = yearPublication;
	}
	
	public int getYearOfPublication() {
		return yearOfPublication;
	}

	public void setYearOfPublication(int yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}

	public void print() {
    	System.out.println("identification number: " + identificationNumber + "\ntitle: " + Title + "\nnumber of copy: " + numberOfCopy + "\nauthor: " + getAuthor() + "\nYearof publication: " + yearOfPublication);
    }

}
