package com.capgemini.Lab7;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise7 {
	public static int[] getSorted(int []num) {
    	int []arr = new int[num.length];
    	for(int i = 0; i < num.length; i++) {
    		String str = Integer.toString(num[i]);
    		StringBuffer sb = new StringBuffer(str);
    		sb = sb.reverse();
    		str = sb.toString();
    		arr[i] = Integer.parseInt(str);
    	}
//    	Comparator<Integer> comp = (a,b) -> Integer.compare(a, b);
//    	Collections.sort(Arrays.asList(num));
    	Arrays.sort(arr);
    	return arr;
    }
	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter number of elemets: ");
    int num = sc.nextInt();
    int arr[] = new int[num];
    for(int i = 0; i < num; i++) {
    	arr[i] = sc.nextInt();
    }
    sc.close();
    for(int i: getSorted(arr))
    	System.out.print(i + " ");
	}
	
}
