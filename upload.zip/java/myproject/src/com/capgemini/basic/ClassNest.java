package com.capgemini.basic;

public class ClassNest {
        class Member{
        	public void hi() {System.out.println("Hi....");}
        }
        static class Child{
        	public void hello() {System.out.println("Hello.....");}
        }
	public static void main(String[] args) {
	      ClassNest nest = new ClassNest();
	      Member m = nest.new Member();
	      m.hi();
	      Child ch = new Child();
	      ch.hello();

	}

}
