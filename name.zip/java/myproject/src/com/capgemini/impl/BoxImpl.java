package com.capgemini.impl;

import com.capgemini.basic.Box;

public class BoxImpl {
	public static void main(String[] args) {
		Box box = new Box();   // instantiation of object of Box class
		System.out.println("Height : " + box.getHeight());
		System.out.println("Width : " + box.getWidth());
//		box.setHeight(100);
//		box.setWidth(100);
		Box b1 = new Box(10,20);
		System.out.println("Width : " + b1.getWidth());
		System.out.println("Height : " + b1.getHeight());
		System.out.println(box);
		box = null;
		b1 = null;
//		System.gc();
		Runtime.getRuntime().gc();
	    
	}
	

}
