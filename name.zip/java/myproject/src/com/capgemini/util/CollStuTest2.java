package com.capgemini.util;

import java.util.TreeSet;

import java.util.Iterator;

public class CollStuTest2 {

	public static void main(String[] args) {
      TreeSet<Student> stud = new TreeSet<>();
      stud.add(new Student(103, "Aman"));
      stud.add(new Student(101, "Raj"));
      stud.add(new Student(303, "Amar"));
      stud.add(new Student(101, "Raj"));
      System.out.println(stud);
      
      Iterator<Student> itr = stud.descendingIterator();
       while(itr.hasNext()) {
    	   System.out.println(itr.next());
       }
      
      
	}

}
