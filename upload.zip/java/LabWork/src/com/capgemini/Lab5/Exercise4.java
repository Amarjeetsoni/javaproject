package com.capgemini.Lab5;

import java.util.Scanner;

public class Exercise4 {
   public static void main(String[] args) {
	try {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter firstName: ");
		String firstName = scan.nextLine();
		System.out.println("Enter Last name: ");
		String lastName = scan.nextLine();
		scan.close();
		if(firstName.length() == 0 && lastName.length() == 0)
			throw new Exception("Name is Not valid");
		System.out.println("FullName: " + firstName + " " + lastName);
	}catch(Exception e) {
		System.out.println(e);
	}
}
}
