package com.capgemini.Lab10.StreamAPI;


public class Department {
   protected int departmentId, managerId;
   protected String departmentName;
  public Department() {}
   public Department(int departmentId, int managerId, String departmentName) {
	this.departmentId = departmentId;
	this.managerId = managerId;
	this.departmentName = departmentName;
}
   
public int getDepartmentId() {
	return departmentId;
}
public void setDepartmentId(int departmentId) {
	this.departmentId = departmentId;
}
public int getManagerId() {
	return managerId;
}
public void setManagerId(int managerId) {
	this.managerId = managerId;
}
public String getDepartmentName() {
	return departmentName;
}
public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
}
   
}
