package com.capgemini.array;
import java.util.Arrays;
import java.util.Scanner;
public class ArrayTest3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int arr[][] = new int[3][];
       Scanner scan = new Scanner(System.in);
   	   for(int i = 0; i < arr.length; i++)
    	{
   		   System.out.println("Enter size of " + (i+1) + " row");
   		   int num = scan.nextInt();
   		   arr[i] = new int[num];
    	}
   	   System.out.println("Enter the array elemets: ");
   	   for(int i = 0; i < arr.length; i++)
   	   {
   		   System.out.println("Enter " + arr[i].length + " Elemnets: ");
   		   for(int j = 0; j < arr[i].length; j++)
   		   {
   			   arr[i][j] = scan.nextInt();
   		   }
   	   }
   	   System.out.println("The elemet of an array is: ");
   	   for(int i = 0; i < arr.length; i++)
   	   {
   		   for(int j = 0; j < arr[i].length; j++)
   		   {
   			   System.out.print(arr[i][j] + " ");
   		   }
   		   System.out.print("\n");
   	   }
	}

}
