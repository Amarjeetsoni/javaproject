package com.capgemini.exp;

public class ExpTest3 {
   public static void verifyUsernameLength(String username) throws UsernameValidationException{
//	   int number = 0,chara = 0,special = 0;
//	   for(int i = 0; i < username.length(); i++) {
//		   if((username.charAt(i) >= 'a' && username.charAt(i) <= 'z') || (username.charAt(i) >= 'A' && username.charAt(i) <= 'Z'))
//		   {
//			   chara++;
//		   }
//	   }
	   if(username.length() < 6) {
		   throw new UsernameValidationException("Username must be of minimum 6 latter");
	   }
	   else
		   System.out.println("valid username found");
   }
	public static void main(String[] args) {
	try {
		verifyUsernameLength("Admi");
	}catch(Exception e) {
		System.out.println(e);
	}

	}

}
