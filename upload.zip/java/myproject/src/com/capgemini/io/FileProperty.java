package com.capgemini.io;

import java.io.File;
import java.util.Scanner;

public class FileProperty {

	public static void main(String[] args) throws Exception{
             Scanner scan = new Scanner(System.in);
             String str = scan.nextLine();
             File myFile = new File("D:\\fileHandling",str);
             if(myFile.exists()) {
            	 System.out.println("File Exist");
            	 if(myFile.canRead()) {
            		 System.out.println("File is readable");
            	 }else
            		 System.out.println("File is not Readable");
            	 if(myFile.canWrite()) {
            		 System.out.println("File is writable");
            	 }else
            		 System.out.println("File is not writable");
            	 if(myFile.isDirectory()) {
            		 System.out.println("is a dirctory");
            	 }else
            		 System.out.println("is not a directory");
            	 System.out.println("length in byte: " + myFile.length());
            	 System.out.println("Name of file: " + myFile.getName());
             }
             else
             {
            	 System.out.println("File Does not Exist");
             }
             scan.close();
	}

}
