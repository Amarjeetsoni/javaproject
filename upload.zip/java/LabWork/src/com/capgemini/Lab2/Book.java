package com.capgemini.Lab2;
import java.util.Scanner;

public class Book extends WrittenItem {

	public Book() {
		
	}
	public Book(String identificationNumber, String title, int numberOfCopy, String author) {
		super(identificationNumber, title, numberOfCopy, author);
	}

	@Override
	void addItem() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Identification number: ");
		setIdentificationNumber(scan.next());
	    System.out.println("Enter title: ");
	    setTitle(scan.next());
	    System.out.println("Enter number of copy: ");
	    setNumberOfCopy(scan.nextInt());
	    System.out.println("Enter author: ");
	    setAuthor(scan.nextLine());
		scan.close();
	}

}
