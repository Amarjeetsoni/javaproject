package com.capgemini.Lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Exercise1 {
	 public static List<String> getValues(Map<Integer, String> mp){
		   List<String> str = new ArrayList<>(mp.values());
		   Collections.sort(str);
		   return str; 
	   }
		public static void main(String[] args) {
			Map<Integer, String> mp = new  HashMap<>();
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Number: ");
	        int num = sc.nextInt();
	        for(int i = 0; i < num; i++) {
	        	String str = sc.next();
	        	mp.put(i,str);
	        }
	        sc.close();
	        System.out.println(getValues(mp));
		}

}
