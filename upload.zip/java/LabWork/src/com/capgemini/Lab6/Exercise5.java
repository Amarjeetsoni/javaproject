package com.capgemini.Lab6;

import java.util.Scanner;

public class Exercise5 {
   public static int modifyNumber(int number) {
	   String str = Integer.toString(number);
	   String modify = "";
	   for(int i = 0; i < str.length()-1; i++) {
		   int ch1 = (str.charAt(i) - '0');
		   int ch2 = (str.charAt(i+1) - '0');
		   modify += Integer.toString(Math.abs(ch1-ch2));
	   }
	   modify += str.charAt(str.length()-1);
	   number = Integer.parseInt(modify);
	   return number;
   }
   public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter a number: ");
	int number = scan.nextInt();
	System.out.println("modify Number: " + modifyNumber(number));
	scan.close();
}
}
