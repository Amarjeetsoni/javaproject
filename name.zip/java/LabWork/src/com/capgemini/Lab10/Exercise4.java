package com.capgemini.Lab10;
interface Create{
	void say();
}
public class Exercise4 {
    int num;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public void told() {
    	System.out.println("This is a method called by Inteface refrence");
    }
    public static void main(String[] args) {
		Exercise4 ex = new Exercise4();
		Create ct = ex::told;
		ct.say();
	}
}
