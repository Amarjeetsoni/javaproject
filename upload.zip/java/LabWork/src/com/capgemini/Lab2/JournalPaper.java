package com.capgemini.Lab2;

import java.util.Scanner;

public class JournalPaper extends WrittenItem {
    private int YearofPublication;
    public JournalPaper() {
    	
    }
	public JournalPaper(String identificationNumber, String title, int numberOfCopy, String author, int YearofPublication) {
		super(identificationNumber, title, numberOfCopy, author);
	        this.YearofPublication = YearofPublication;
	}

	public int getYearofPublication() {
		return YearofPublication;
	}

	public void setYearofPublication(int yearofPublication) {
		YearofPublication = yearofPublication;
	}

	@Override
	void addItem() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Identification number: ");
		setIdentificationNumber(scan.next());
	    System.out.println("Enter title: ");
	    setTitle(scan.next());
	    System.out.println("Enter number of copy: ");
	    setNumberOfCopy(scan.nextInt());
	    System.out.println("Enter author: ");
	    setAuthor(scan.nextLine());
	    System.out.println("Enter Year of Publication: ");
	    setYearofPublication(scan.nextInt());
		scan.close();

	}

}
