package com.project.bean;
import java.util.Scanner;
public class PersonImpl implements PersonOpr{
    public static Person []per = new Person[3];
    public static int num = 0;
	@Override
	public void addPerson(Person p) {
		per[num] = p;
		System.out.println("record Added successfully");
		num++;
	}
    public static void display(Person p) {
    	System.out.println("Name: " + p.name);
    	System.out.println("Id: " + p.Id);
    	System.out.println("job: " + p.job);
    }
	@Override
	public Person[] getPerson() {
		return per; 
	}
	public static void main(String[] args) {
		System.out.println("Enter details of 3 person: ");
		 PersonImpl p = new PersonImpl();
		 Person p1=new Person();;
	   for(int i = 0; i < 3; i++) {
		  // p1 = 
		   Scanner Scan = new Scanner(System.in);
		   Scanner Scan1 = new Scanner(System.in);
			System.out.print("Enter Persons ID: ");
			p1.Id = Scan.next();
			System.out.print("Enter Person Name: ");
			p1.name = Scan1.nextLine();
			System.out.print("Enter Person job: ");
			p1.job = Scan.next();
		    p.addPerson(p1);
	   }
	   Person[] find = new Person[3];
	   find = p.getPerson();
	   System.out.println("Final details: ");
	   for(int i = 0; i < 3; i++) {
		   System.out.println("Person" + (i+1) + " details are: ");
		   PersonImpl.display(find[i]);
	   }
	}
     
}
