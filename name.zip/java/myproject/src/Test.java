
public class Test{
	    	static int i;
	        public static void main(String args[]) {
	        	 float f = 1.5;
	        	 System.out.println(I);
	        	while (i < 0) {
	            i--;
	            }
	    	  System.out.println(i);
	       }
	}

