package com.capgemini.Lab7;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Exercise6 {
	public static List<Integer> votersList(Map<Integer, Integer> Person){
		  List<Integer> li = new ArrayList<Integer>();
		  for(int i: Person.keySet()) {
			  if(Person.get(i) > 18) {
				  li.add(i);
			  }
		  }
		  return li;
	  }
	  public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number of People: ");
		int number = sc.nextInt();
	    Map<Integer, Integer> mp = new HashMap<>();
		for(int i = 0; i < number; i++) {
			System.out.println("Enter Id: ");
			int id = sc.nextInt();
			System.out.println("Enter Age: ");
			int age = sc.nextInt();
			mp.put(id, age);
		}
		System.out.println("Id's are: ");
		System.out.println(votersList(mp));
		sc.close();
	}
}
