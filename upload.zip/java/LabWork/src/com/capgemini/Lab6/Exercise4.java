package com.capgemini.Lab6;

import java.util.Scanner;

public class Exercise4 {
     public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String: ");
		String str1 = sc.nextLine();
		StringBuffer str = new StringBuffer(str1);
		for(int i = 0; i < str.length(); i++) {
			char ch1 = str.charAt(i);
			if(ch1 != 'A' && ch1 != 'E' && ch1 != 'I' && ch1 != 'O' && ch1 != 'U' && ch1 != 'a' && ch1 != 'e' && ch1 != 'i' && ch1 != 'o' && ch1 != 'u' && ch1 != ' ')
			{
				char ch = (char)(str.charAt(i)+1);
				str.setCharAt(i, ch);
			}
		}
		System.out.println(str);
		sc.close();
	}
}
