package com.capgemini.io;

import java.io.FileOutputStream;
import java.util.Scanner;

public class MyRecord {
   public static void main(String[] args) {
	try {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of record You want to enter: ");
		int num = sc.nextInt();
		FileOutputStream myrecord = new FileOutputStream("D:\\fileHandling\\filerecord.txt", true);
		int n = 1;
		System.out.println("Record should be in form of ID, NAME, SALARY::::");
		while(n <= num) {
			System.out.println("Enter " + n + "th record: ");
		    Scanner scan = new Scanner(System.in);
			String Name = scan.nextLine();
			Name = Name + "\n";
			myrecord.write(Name.getBytes());
			n++;
//			scan.close();
		}
		System.out.println("Record saved!");
		sc.close();
		myrecord.close();
		
	}catch(Exception e) {
		System.out.println(e);
	}
}
}
