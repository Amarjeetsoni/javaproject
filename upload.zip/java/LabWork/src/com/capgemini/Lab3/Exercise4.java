package com.capgemini.Lab3;

import java.util.Scanner;

public class Exercise4 {
       public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Character array: ");
		String str = scan.next();
		int arr[] = new int[255];
		for(int i = 0; i < 255; i++)
			arr[i] = 0;
		for(int i = 0; i < str.length(); i++) {
			int num = str.charAt(i);
			arr[num]++;
		}
		for(int i = 0; i < 255; i++)
		{
			if(arr[i] != 0) {
				char ch = (char)(i);
				System.out.println(ch + " : " + arr[i]);
			}
		}
		scan.close();
	}
}
