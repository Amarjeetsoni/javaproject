/*Satck operation to store names of person and dispaly
 * perform queue prpcess to store and display
 * */

package com.capgemini.util;

import java.util.LinkedList;
import java.util.Scanner;

class Name{
	private String name;

	public Name(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return  name;
	}
}
public class ColltestLinkedList {
  public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	LinkedList<Name> ls = new LinkedList<>();
	System.out.println("Enter Number of person: ");
	int size = sc.nextInt();
	for(int i = 0; i < size; i++) {
		ls.addLast(new Name(sc.next()));
	}
	System.out.println("Using Satck operation: ");
	while(ls.size() > 0) {
		System.out.println(ls.getLast());
		ls.removeLast();
	}
	System.out.println("Using Queue: ");
	for(int i = 0; i < size; i++) {
		ls.addLast(new Name(sc.next()));
	}
	while(ls.size() > 0) {
		System.out.println(ls.getFirst());
		ls.removeFirst();
		}
	sc.close();
}
}
