package com.capgemini.JDBC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Author {
	 public static void insert(Connection conn) throws SQLException, NumberFormatException, IOException {
	    	System.out.print("Author Id:  ");
	    	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	    	int id = Integer.parseInt(bf.readLine());
	    	System.out.print("Author First_Name: ");
	    	 String name_first = bf.readLine();
	    	 System.out.print("Author Middle_name: ");
	    	 String name_middle = bf.readLine();
	    	 System.out.print("Author Last_name: ");
	    	 String name_Last = bf.readLine();
	    	 System.out.print("Author Mobile No: ");
	    	 String mobNo = bf.readLine();
	    	String str = "insert into Author values(?,?,?,?,?)";
	    	PreparedStatement stmt = conn.prepareStatement(str);
	    	stmt.setInt(1, id);
	    	stmt.setString(2, name_first);
	    	stmt.setString(3, name_middle);
	    	stmt.setString(4,name_Last);
	    	stmt.setString(5, mobNo);
	    	stmt.executeUpdate();
	    	System.out.println("Record Inserted..");
	    }
	    public static void select(Connection conn) throws SQLException, IOException {
	    	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	    	System.out.print("Enter specific Id or enter \"all\" for all details: ");
	    	String str1 = bf.readLine();
	    	String str;
	    	PreparedStatement stmt; // conn.prepareStatement(str);
	    	if(str1.equals("all")) {
	    	str = "select * from author";
	    	stmt = conn.prepareStatement(str);
	    	}
	    	else {
	    		str = "select * from author where authorId = ?";
	    		stmt = conn.prepareStatement(str);
	    	    int num = Integer.parseInt(str1);
	    	    stmt.setInt(1, num);
	    	}
	    	ResultSet rs = stmt.executeQuery();
	    	while(rs.next()) {
	    		System.out.println(rs.getInt(1) + "    " + rs.getString(2) + " " + rs.getString(3) +  " " + rs.getString(4) +" " +  rs.getString(5));
	    	}
	    }
	    public static void update(Connection conn) throws SQLException, IOException{
	    	System.out.println("set: ");
	    	BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
	    	String str1 = sc.readLine();
	    	System.out.println("values: ");
	    	String num = sc.readLine();
	    	System.out.println("Where: ");
	    	String str2 = sc.readLine();
	    	System.out.println("values: ");
	        int num2 = Integer.parseInt(sc.readLine());
	    	String str = "update author set " + str1 + " = ? where " + str2 + " = ?";
	    	PreparedStatement stmt = conn.prepareStatement(str);
	    	stmt.setString(1, num);
	    	stmt.setInt(2, num2);
	    	stmt.executeUpdate();
	    	System.out.println("Record updated..");
	    }
	    public static void delete(Connection conn) throws SQLException, IOException{
	    	BufferedReader sc = new BufferedReader(new InputStreamReader(System.in));
	    	System.out.println("Where: ");
	    	String str1 = sc.readLine();
	    	System.out.println("values: ");
	        int num = Integer.parseInt(sc.readLine());
	    	String str = "delete from author where " + str1 + " = ?";
	    	PreparedStatement stmt = conn.prepareStatement(str);
	    	stmt.setInt(1, num);
	    	stmt.executeUpdate();
	    	System.out.println("Record deleted..");
	    }
	    
   public static void main(String[] args) throws SQLException, NumberFormatException, IOException{
	   Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr", "hr");
//	String str = "create table Author(authorId number(5), firstName varchar2(10), middleName varchar2(10), lastName varchar2(10), phoneNo number)";
//	Statement stmt = conn.createStatement();
//	stmt.executeUpdate(str);
	System.out.println("table Created");
	while(true) {
		System.out.print("Choose: \n1.insert()\n2.select()\n3.update()\n4.delete()\nEnter choise:");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		switch(n) {
		case 1:
			insert(conn);
			break;
		case 2:
			select(conn);
			break;
		case 3:
			update(conn);
			break;
		case 4:
			delete(conn);
			break;
		default:
			System.out.println("Try again...");
		}
		}
	
	
}
}
