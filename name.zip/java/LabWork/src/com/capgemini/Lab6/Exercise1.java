package com.capgemini.Lab6;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Exercise1 {
         public static void main(String[] args) {
	  Scanner scan = new Scanner(System.in);
	  String line = scan.nextLine();
	  StringTokenizer str1 = new StringTokenizer(line);
	  int sum = 0;
	  while(str1.hasMoreTokens()) {
	      int num = Integer.parseInt(str1.nextToken());
		  sum += num;
	      System.out.println(num);
	  }
	  System.out.println("Sum of Numbers: " + sum);
	  scan.close();
	  
  }
}
