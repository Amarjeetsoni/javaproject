package com.capgemini.util;
import java.util.ArrayList;
import java.util.Iterator;
class Person{
	private String pname;
	private int salary;
	public Person(String pname, int salary) {
		this.pname = pname;
		this.salary = salary;
	}
	
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Person [pname=" + pname + ", salary=" + salary + "]";
	}
}
public class CollTestList2 {
public static void main(String[] args) {
	 ArrayList<Person> person = new ArrayList<>();
	 person.add(new Person("AMAR", 45000));
	 person.add(new Person("Hari", 25000));
	 person.add(new Person("Vani", 56000));
	 person.forEach(System.out::println);
	 for(int i = 0; i < person.size(); i++) {
		 System.out.println(person.get(i));
	 }
	 for(int i = 0; i < person.size(); i++) {
		 System.out.print("name = " + person.get(i).getPname() + "\nSalary: " + person.get(i).getSalary() + "\n");
	 }
	 Iterator<Person> itr = person.iterator();
	 while(itr.hasNext()) {
		 System.out.println(itr.next());
	}
}
}
