class Dog{
	public String animal = "Dog";
	void name1() {
		System.out.println("Barking");
	}
}
class goat extends Dog{
	public String animal = "goat";
	void name1() {
		System.out.println("Goat");
	}
}
public class MainClass {
   public static void main(String[] args) {
	Dog D1 = new goat();
	System.out.println();
}
}
