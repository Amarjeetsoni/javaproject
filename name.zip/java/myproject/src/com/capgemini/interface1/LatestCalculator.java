package com.capgemini.interface1;

public interface LatestCalculator {
  public int getNum();
  public void setNum(int n);
  public default int calSquare(int n) {
	  return n*n;
  }
  public default boolean findEven() {
	  return getNum()%2 == 0;
  }
  public static String invite(String name) {
	  return "HEllo!.. " + name;
  }
}
