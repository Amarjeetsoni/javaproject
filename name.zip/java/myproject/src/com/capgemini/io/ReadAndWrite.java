package com.capgemini.io;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class ReadAndWrite {

	public static void main(String[] args) throws Exception{
        try {
		FileReader file = new FileReader("D:\\fileHandling\\first.txt");
        FileWriter newFile = new FileWriter("D:\\fileHandling\\newFile.txt");
        BufferedReader buffer = new BufferedReader(file);
        String str = "";
        while((str = buffer.readLine()) != null) {
        	newFile.write(str + "\n");
        }
        System.out.println("File Copyed Successfully");
        newFile.close();
        buffer.close();
        }catch(Exception e) {
        	System.out.println(e);
        }
	}

}
