package com.capgemini.interface1;

public class CalImpl implements LatestCalculator {
   private int n;
	public int getNum() {
		return n;
	}
	public void setNum(int n) {
         this.n = n;
	}

	public static void main(String[] args) {
		System.out.println(LatestCalculator.invite("AMARJEET"));
		CalImpl cal = new CalImpl();
		cal.setNum(10);
		System.out.println("Value set: " + cal.getNum());
		System.out.println(cal.calSquare(cal.getNum()));

	}

}
