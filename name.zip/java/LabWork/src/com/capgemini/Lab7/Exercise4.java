package com.capgemini.Lab7;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

public class Exercise4 {
	 public static Map<Integer, String> getStudents(Map<Integer, Integer> Student){
		   Map<Integer, String> mp = new HashMap<>();
	       Iterator<Map.Entry<Integer, Integer>> itr = Student.entrySet().iterator();
	       while(itr.hasNext()) {
	    	   Entry<Integer, Integer> in = itr.next();
	    	   if(in.getValue() >= 90)
	    	   {
	    		   mp.put(in.getKey(), "Gold");
	    	   }
	    	   else if(in.getValue() >= 80 && in.getValue() < 90) {
	    		   mp.put(in.getKey(), "Silver");
	    	   }
	    	   else if(in.getValue() >= 70 && in.getValue() < 80) {
	    		   mp.put(in.getKey(), "Bronze");
	    	   }
	    	   else
	    		   mp.put(in.getKey(), "Not Eligible");
	       }
	       return mp;
	   }
		public static void main(String[] args) {
	         Scanner sc = new Scanner(System.in);
	         System.out.println("Enter the number of Details: ");
	         int size = sc.nextInt();
	         Map<Integer, Integer> mp = new HashMap<>();
	         for(int i = 0; i < size; i++) {
	        	 System.out.println("Enter reg. No.: ");
	        	 int reg = sc.nextInt();
	        	 System.out.println("Enter number: ");
	        	 int num = sc.nextInt();
	        	 mp.put(reg, num);
	         }
	         Map<Integer, String> op = new HashMap<>();
	         op = getStudents(mp);
	         Iterator<Map.Entry<Integer, String>> itr = op.entrySet().iterator();
	         System.out.println("Details of Results: ");
	         while(itr.hasNext()) {
	        	 Entry<Integer, String> in = itr.next();
	        	 System.out.println(in.getKey() + "  " + in.getValue());
	         }
	         sc.close();
	        }
}
