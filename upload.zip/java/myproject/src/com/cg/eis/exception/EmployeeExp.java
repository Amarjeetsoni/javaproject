package com.cg.eis.exception;

public class EmployeeExp extends Exception {
   public EmployeeExp() {
	   super("salary is below 3000");
   }
   public EmployeeExp(String s) {
	   super(s);
   }
}
