package com.capgemini.Lab1;

import java.util.Scanner;

public class Exercise2 {
    public static int calculateDifference(int num) {
    	int num1 = 0, num2 = 0;
    	for(int i = 1; i <= num; i++) {
    		num1 += i*i;
    		num2 += i;
    	}
    	num2 = num2*num2;
    	return Math.abs(num1-num2);
    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int number = sc.nextInt();
		System.out.println("diffrence between both is: " + calculateDifference(number));
        sc.close();
	}

}
