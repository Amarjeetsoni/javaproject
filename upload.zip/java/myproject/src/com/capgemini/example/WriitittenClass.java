package com.capgemini.example;

public class WriitittenClass {

	public static void main(String[] args) {
		JournalPaper BookName = new JournalPaper(10001, "The new Book", 5, "AMAR", 2000);
        BookName.print();
        System.out.println(BookName);
        System.out.println("New class Item");
        Book BookName1 = new Book(10001, "The new Book", 5, "AMAR");
        BookName1.print();
	}

}