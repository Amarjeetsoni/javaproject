package com.capgemini.Lab6;

import java.util.Scanner;

public class Exercise8 {
   public static boolean checkString(String str) {
	   char ch = str.charAt(0);
	   for(int i = 1; i < str.length(); i++) {
		   if(str.charAt(i) >= ch)
		   {
			   ch = str.charAt(i);
		   }
		   else
			   return false;
	   }
	   return true;
   }
   public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter String: ");
	String str = sc.nextLine();
	System.out.println(checkString(str)?"String is Positive string":"String is not a positive string");
	sc.close();
}
}
