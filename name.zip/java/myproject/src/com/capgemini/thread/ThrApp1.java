package com.capgemini.thread;

public class ThrApp1 extends Thread{
    public ThrApp1(String name) {
    	setName(name);
    	start();
    }
    public void run() {
    	try{
    	for(int i = 1; i <= 10; i++) {
    		System.out.println(getName() + ">" + i);
    		sleep(500);
    	}
    	}catch(Exception ex) {
    		System.out.println(ex);
    	}
    }
    
    
    public static void main(String[] args) {
		ThrApp1 t1 = new ThrApp1("First");
		             new ThrApp1("Next");
	}
}
