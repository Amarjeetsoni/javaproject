package com.capgemini.io;

import java.io.BufferedReader;
import java.io.FileReader;

public class CountCharFromFile {
     public static void main(String[] args) throws Exception {
	FileReader file = new FileReader("D:\\fileHandling\\first.txt");
	BufferedReader buffer = new BufferedReader(file);
	String str = "";
	int line = 0;
	int chara = 0;
	int word = 0;
	while((str = buffer.readLine()) != null) {
       line++;
       chara += str.length();
       word += str.split(" ").length;
//		StringTokenizer tk = new StringTokenizer(str, "\n");
//		StringTokenizer tk1 = new StringTokenizer(str, " ");
//		while(tk.hasMoreTokens()) {
//			chara += tk.nextToken().length();
//		}
//		while(tk1.hasMoreTokens()) {
//			tk1.nextToken();
//			word++;
//		}
//		line++;
	}
	
	System.out.println("Number of line: " + line);
	System.out.println("Number of charater: " + chara);
	System.out.println("Number of Word: " + word);
	buffer.close();
	
 }
}
