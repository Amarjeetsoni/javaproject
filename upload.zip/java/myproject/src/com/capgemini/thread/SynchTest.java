package com.capgemini.thread;

class Message{
	public synchronized void sendMesg(String receiver) {          // making syncronized to serial exicution of program
		String mesgs[] = {"First", "Second","Third"};
		try {
			for(String m:mesgs) {
				System.out.println(m + " Received by " + receiver);
				Thread.sleep(1000);
			}
		}catch(Exception e) {
			System.out.println(e);
		}
	}
}
class Publisher extends Thread{
	private String receiver;
	private Message mesg;
	public Publisher(String receiver, Message mesg) {
		this.receiver = receiver;
		this.mesg = mesg;
		start();
	}
	public void run() {
		mesg.sendMesg(receiver);
	}
	
}
public class SynchTest {

	public static void main(String[] args) {
      Message m = new Message();
      Publisher pb1 = new Publisher("Person1", m);
      Publisher pb2 = new Publisher("Person2", m);
      try {
    	  pb2.join(1000);    // this thread get closed after 1sec and after pb2 is starts
    	  
      }catch(Exception e) {
    	  System.out.println(e);
      }
	}

}
