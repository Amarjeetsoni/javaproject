package com.capgemini.Lab10;

import java.util.Scanner;

interface SpaceSep{
	String space(String str);
}
public class Exercise2 {
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String: ");
		String str = sc.next();
		sc.close();
		SpaceSep sp = (s)->{String str1 = "";
		for(int i = 0; i < s.length(); i++) {
			str1 += s.charAt(i) + " ";
		}
		return str1;
			};
		System.out.println("After sep: " + sp.space(str));
			
	}
}
