package com.capgemini.Lab6;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class Exercise2 {
  public static void main(String[] args) {
	try{
		FileInputStream file = new FileInputStream("D:\\fileHandling\\first.txt");
		DataInputStream data = new DataInputStream(file);
		String str = "";
		int num = 1;
		while((str = data.readLine()) != null) {
			System.out.print(num + ".");
			System.out.println(str);
			num++;
		}
		data.close();
	}catch(Exception e) {
		System.out.println(e);
	}
	
}
}
