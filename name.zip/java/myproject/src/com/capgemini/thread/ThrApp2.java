package com.capgemini.thread;

public class ThrApp2 extends Thread{
  public void run() {
	  try {
		  for(int i = 1; i <= 5; i++) {
			  if(i%3 == 0)
				  interrupt();
			  else
			  System.out.println(getName() + " > " + i);
			  sleep(500);
		  }
	  }catch(Exception ex) {
		  System.out.println(ex);
	  }
  }
	public static void main(String[] args) {
      new ThrApp2().start();
	}

}
