package com.capgemini.Lab6;

import java.util.Scanner;

public class Exercise10 {
    public static boolean validation(String name) {
    	String str = name.substring(name.length()-4);
    	if(str.equals("_job")) {
    		int length = name.length() - 4;
    		if(length >= 8)
    			return true;
    		else
    			return false;
    	}else
    		return false;
    }
	public static void main(String[] args) {
          Scanner scan = new Scanner(System.in);
          System.out.println("Enter Username: ");
          String str = scan.next();
          System.out.println(validation(str)?"Validation passed!!":"Validation Failed..");
          scan.close();
	}

}
