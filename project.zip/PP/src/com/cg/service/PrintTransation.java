package com.cg.service;

public interface PrintTransation {
     void printallTransation(String user, String pass);
}
