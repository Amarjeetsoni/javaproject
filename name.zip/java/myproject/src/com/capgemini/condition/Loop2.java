package com.capgemini.condition;

import java.util.Scanner;

public class Loop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner scan = new Scanner(System.in);
    int num = scan.nextInt();
    int number = 0;
    int act = num;
    while(num > 0)
    {
    	number = number*10 +  num % 10;
    	num = num /10;
    }
    System.out.println("reverse of number is: " + number);
    if(act == number)
    {
    	System.out.println("number is palendrome");
    }
    else
    {
    	System.out.println("Number is not a palendrom");
    }
	}

}
