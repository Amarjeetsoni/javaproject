package com.capgemini.thread;

public class SalesPerson extends Thread{
    String person[] = {"amar", "ankit", "saurav", "Pritam", "avinash"};
	public void run() {
//		new Days().start();
    	try {
    		for(String str: person) {
    		System.out.print("\n" + str + ": ");
    		sleep(500);
    		
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    }
}
