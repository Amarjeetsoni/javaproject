package com.capgemini.basic;

public class Box {
 int width, height;

public Box() {
	width = 50;
	height = 80;
}


public Box(int width, int height) {
	this.width = width;
	this.height = height;
}


public int getWidth() {
	return width;
}

public void setWidth(int width) {
	this.width = width;
}

public int getHeight() {
	return height;
}

public void setHeight(int height) {
	this.height = height;
}


@Override
public String toString() {    // to override the object 
	return "Box [width=" + width + ", height=" + height + "]";
}


@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		System.out.println("Object relesed");
	}
}
