package com.capgemini.inheritance;

public class Employee {
    private int Id;
    private String ename;
    private String job;
    public Employee() {
    	
    }
	public Employee(int id, String ename, String job) {
		Id = id;
		this.ename = ename;
		this.job = job;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
    
    
}
