package com.capgemini.util;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class CollSetTest1 {

	public static void main(String[] args) {
//     Set<Integer> mySet = new HashSet<>();    // upcasting
//     Set<Integer> mySet = new LinkedHashSet<>();    // upcasting
		Set<Integer> mySet = new TreeSet<>();
     Scanner scan = new Scanner(System.in);
     for(int i = 1; i <= 5; i++) {
    	 System.out.println("Elements: ");
    	 mySet.add(scan.nextInt());
     }
     mySet.forEach(System.out::println);
	}

}
