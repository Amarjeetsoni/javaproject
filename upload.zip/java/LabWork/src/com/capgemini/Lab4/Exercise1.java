package com.capgemini.Lab4;

import java.util.Scanner;

public class Exercise1 {
    public static int sumOfcube(int number) {
    	int num = 0;
    	while(number > 0) {
    		int temp = number%10;
    		num += temp*temp*temp;
    		number /= 10;
    	}
    	return num;
    }
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a number: ");
		int number = scan.nextInt();
		System.out.println("Sum of cube of digit of a number: " + sumOfcube(number));
		scan.close();
	}
}
