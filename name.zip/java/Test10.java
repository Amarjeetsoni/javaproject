public class Test10{
  public static void main(String args[]){
     
 
}
}