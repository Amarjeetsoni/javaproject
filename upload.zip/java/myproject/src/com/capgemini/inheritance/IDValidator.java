package com.capgemini.inheritance;

public abstract class IDValidator {
private String ID;

protected String getID() {
	return ID;
}

protected void setID(String iD) {
	ID = iD;
}
  public abstract boolean validation();
}


