package com.capgemini.arch.service;

import java.util.List;

import com.capgemini.arch.bean.EmployeeBean;
import com.capgemini.arch.dao.EmployeeDAOImpl;

public class EmployeeServiceImp implements IEmployeeService {
    EmployeeDAOImpl dao;
    public EmployeeServiceImp() {
		dao = new EmployeeDAOImpl();
	}
	@Override
	public boolean addEmployee(EmployeeBean bean) {
		// you can add additional BL
		dao.addEmployee(bean);
		return true;
	}

	@Override
	public List<EmployeeBean> getEmployees() {
		return dao.getEmployees();
	}

	@Override
	public EmployeeBean findByID(int empid) {
		return dao.getEmployeeById(empid);
	}

}
