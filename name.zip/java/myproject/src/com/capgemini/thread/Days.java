package com.capgemini.thread;

public class Days extends Thread{
	 String person[] = {"Monday", "Tuesday", "Wednesday", "Thrusday", "Friday", "Saturday", "Sunday"};
		public void run() {
	    	try{for(String str: person) {
	    		System.out.print(str + " ");	
	    		sleep(450);
	    	}
	    	}catch(Exception e) {
	    	System.out.println(e);
	    }
}
}

