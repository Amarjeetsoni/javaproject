package com.capgemini.inheritance;

public class PartTimeEmployee extends Employee {
  private int hours;
  private int salary;
public PartTimeEmployee(int id, String ename, String job, int hours, int salary) {
	super(id, ename, job);
	this.hours = hours;
	this.salary = salary;
}
public int getHours() {
	return hours;
}
public void setHours(int hours) {
	this.hours = hours;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}

public void viewDetails() {
	System.out.println("Id: " + getId());
	System.out.println("Name: " + getEname());
	System.out.println("Job: " + getJob());
	System.out.println("Salary: " + getSalary());
	System.out.println("HOURS: " + getHours());
}
    
  
}
