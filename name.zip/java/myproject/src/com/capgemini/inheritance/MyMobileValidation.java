package com.capgemini.inheritance;

public class MyMobileValidation extends IDValidator {

	@Override
	public boolean validation() {
		// TODO Auto-generated method stub
		if(getID().length() == 10)
			return true;
		return false;
	}
	public static void main(String[] args) {
		MyMobileValidation mobile = new MyMobileValidation();
		mobile.setID("1234567891");
		System.out.println(mobile.validation()? "valid number" :"Invalid number");
	}

}
