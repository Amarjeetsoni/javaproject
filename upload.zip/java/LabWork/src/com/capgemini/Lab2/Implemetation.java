package com.capgemini.Lab2;

public class Implemetation {
   public static void main(String[] args) {
	Book B1 = new Book("321456", "the maze runner", 100, "Abdul Kalam");
	Book B2 = new Book();
	B2.addItem();
	B1.print();
	B1.checkIn("11/01/2020 10:20:56AM");
	B1.checkOut("11/01/2020 11:30:45AM");
	
	JournalPaper jp = new JournalPaper("321456", "the maze runner", 100, "Abdul Kalam", 1996);
	jp.print();
}
}
