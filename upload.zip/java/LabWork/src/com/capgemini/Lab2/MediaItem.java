package com.capgemini.Lab2;

public class MediaItem extends Item {
   private String runtime;
	public MediaItem() {
	}


	public MediaItem(String identificationNumber, String title, int numberOfCopy, String runtime) {
		super(identificationNumber, title, numberOfCopy);
		this.runtime = runtime;
	}


	@Override
	void print() {
		System.out.println("the details of book is: ");
		System.out.println("Book Name: " + getTitle());
		System.out.println("Identification number: " + getIdentificationNumber());
		System.out.println("Number of copy: " + getNumberOfCopy());
		System.out.println("runtime: " + runtime);
		

	}

	@Override
	void checkIn(String time) {
        System.out.println("CheckIn: " + time);
	}

	@Override
	void checkOut(String time) {
      System.out.println("CheckOUT: " + time);		

	}

}
