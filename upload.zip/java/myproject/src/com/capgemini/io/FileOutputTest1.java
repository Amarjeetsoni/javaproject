package com.capgemini.io;

import java.io.FileOutputStream;
import java.util.Scanner;

public class FileOutputTest1 {

	public static void main(String[] args) {
         try {
        	 FileOutputStream fileOut = new FileOutputStream("D:\\fileHandling\\write.txt",true);  // appending on
        	 int n = 1;
        	 Scanner sc = new Scanner(System.in);
        	 while(n <= 5) {
        		  System.out.print("Line" + n + ": ");
        		  String line = sc.nextLine();
        		  line = line + "\n";
        		  fileOut.write(line.getBytes());
        		  n++;
        	 }
        	 sc.close();
        	 fileOut.close();
        	 System.out.println("File created successfully!!");
         }catch(Exception e) {
        	 System.out.println(e);
         }
	}

}
