package com.cg.service;

public interface Deposit {
    void depositBalance(double money, String user, String pass);
}
