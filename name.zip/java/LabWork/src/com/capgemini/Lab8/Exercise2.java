package com.capgemini.Lab8;

class Timer implements Runnable{
	public void run() {
		try{
			for(int i = 0; i <= 10; i++) {
		    System.out.print(i + " ");
		    Thread.sleep(1000);
			}
			run();
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
}
public class Exercise2 {
   
	 public static void main(String[] args) {
	 Timer td = new Timer();
	 Thread tr = new Thread(td);
	 tr.start();
	 
}
}
