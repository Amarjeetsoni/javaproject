package com.capgemini.JDBC;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Book_Author {
    public static void check(Connection conn) throws IOException, SQLException {
    	System.out.print("Enter Author name: ");
    	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
    	String name = bf.readLine();
    	String str = "select title from book where isbn in (select isbn from bookauthortable where id  = (select id from author_table where name = ?))";
    	PreparedStatement stmt = conn.prepareStatement(str);
    	stmt.setString(1, name);
    	ResultSet result = stmt.executeQuery();
    	while(result.next()) {
    		System.out.println(result.getString(1));
    	}
    }
    @SuppressWarnings("resource")
	public static void insert(Connection conn) throws IOException, SQLException {
    	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
    	System.out.print("Enter name of book: ");
    	String book = bf.readLine();
    	System.out.print("Enter Price: ");
    	int price = Integer.parseInt(bf.readLine());
    	System.out.print("Enter author name: ");
    	String name = bf.readLine();
    	String str = "select * from author_table where name = ?";
    	PreparedStatement stmt = conn.prepareStatement(str);
    	stmt.setString(1, name);
    	ResultSet result = stmt.executeQuery();
    	if(result.next()) {
    	    int autId = result.getInt(1);
    	    str = "insert into book values(isbn.nextval, ?, ?)";
    	    stmt = conn.prepareStatement(str);
    	    stmt.setString(1, book);
    	    stmt.setInt(2, price);
    	    stmt.executeUpdate();
    	    str = "insert into bookauthortable values(isbn.currval, ?)";
    	    stmt = conn.prepareStatement(str);
    	    stmt.setInt(1, autId);
    	    stmt.executeUpdate();
    	    str = "commit";
    	    stmt = conn.prepareStatement(str);
    	    stmt.executeUpdate();
    	    System.out.println("updated sucessfully..");
    	}
    	else {
    		 str = "insert into book values(isbn.nextval, ?, ?)";
    		 stmt = conn.prepareStatement(str);
    		 stmt.setString(1, book);
     	    stmt.setInt(2, price);
    		 stmt.executeUpdate();
    		 str = "insert into author_table values(id.nextval, ?)";
    		 stmt = conn.prepareStatement(str);
    		 stmt.setString(1, name);
     	     stmt.executeUpdate();
     	     str = "insert into author_table values(isbn.currval, id.currval)";
     	     stmt = conn.prepareStatement(str);
    	     stmt.executeUpdate();
     	     str = "commit";
    	    stmt = conn.prepareStatement(str);
    	    stmt.executeUpdate();
     	     System.out.println("updated sucessfully..");
    	} 
    }
    public static void update(Connection conn) throws IOException, SQLException {
    	System.out.print("Enter Author name: ");
    	BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
    	String name = bf.readLine();
    	System.out.print("Enter Price: ");
    	int price = Integer.parseInt(bf.readLine());
    	String str = "update book set price = ? where isbn in (select isbn from bookauthortable where id in (select id from author_table where name = ?))";
    	PreparedStatement stmt = conn.prepareStatement(str);
    	stmt.setInt(1, price);
        stmt.setString(2, name);
	     stmt.executeUpdate();
	     str = "commit";
	    stmt = conn.prepareStatement(str);
	    stmt.executeUpdate();
	    System.out.println("Updated successfully..");
    }
	public static void main(String[] args) throws SQLException, IOException {
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
//        String command = "create sequence id start with 101 increment by 1";
        Statement stmt = conn.createStatement();
//        stmt.executeUpdate(command);
//        command = "create sequence isbn start with 101 increment by 1";
//        stmt.executeUpdate(command);
//        System.out.println("sequence Created...");
//        String command = "create table book(isbn number primary key, title varchar2(50), price number)";
//        stmt.executeUpdate(command);
//        System.out.println("Table Created..");
//        String command = "create table author_table(id number primary key, name varchar2(50))";
//        stmt.executeUpdate(command);
//        System.out.println("Table Created..");
//        String command = "create table BookAuthorTable(isbn integer, id number, foreign key(isbn) references book(isbn), foreign key(id) references author_table(id))";
//        stmt.executeUpdate(command);
//        System.out.println("Table Created..");
         while(true) {
        	 Scanner sc = new Scanner(System.in);
        	 System.out.print("choose: \n1.check bookName by specific author\n2.Insert Values\n3.Update Price\nEnter: ");
        	 int n = sc.nextInt();
        	 switch(n) {
        	 case 1:
        		 check(conn);
        		 break;
        	 case 2:
        		 insert(conn);
        		 break;
        	 case 3:
        		 update(conn);
        		 break;
        	 default:
        	     System.out.println("Select correct number");		 
        	 }
         }
	}
}
