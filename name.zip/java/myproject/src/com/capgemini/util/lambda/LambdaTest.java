package com.capgemini.util.lambda;

interface MyCalc{
	int calculate(int a, int b);
}
public class LambdaTest {
  public static void main(String[] args) {
	MyCalc calc = (a,b)->{return (a+b);};
	System.out.println(calc.calculate(10, 20));
	calc= (a,b)->{ return (a*b);};
	System.out.println(calc.calculate(20, 10));
//	System.out.println(calc.sum(10, 20));
}
}
