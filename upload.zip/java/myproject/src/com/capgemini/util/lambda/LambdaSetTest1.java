package com.capgemini.util.lambda;

import java.util.HashSet;

public class LambdaSetTest1 {
         public static void main(String[] args) {
			HashSet<Employee> emps = new HashSet<>();
			emps.add(new Employee(101, "Amar", 45000, "A"));
			emps.add(new Employee(102, "Satyam", 40000, "A"));
			emps.add(new Employee(104, "Shubham", 50000, "B"));
			emps.add(new Employee(105, "Anuj", 49000, "C"));
			emps.add(new Employee(108, "Venu", 51000, "D"));
			emps.forEach(e->System.out.println(e.getId() + " " + e.getGrade() + " " + e.getName() + "  " + e.getSalary() ));
		    // if we want only A grade person
			System.out.println("output: ");
			emps.stream().filter(e->e.getGrade().equals("A")).forEach(e->System.out.println(e.getId() + " " + e.getGrade() + " " + e.getName() + "  " + e.getSalary()));
            System.out.println("By for loop: ");
            for(Employee e:emps) {
            	if(e.getGrade().equals("A"))
            		System.out.println(e.getId() + " " + e.getGrade() + " " + e.getName() + "  " + e.getSalary());
            }
            
            // Next method to count number of A gread
            long c = emps.stream().filter(e->e.getGrade().equals("A")).count();
            System.out.println("Count of Emps in 'A' gread: " + c);
            emps.stream().filter(e->e.getSalary() > 45000 && e.getSalary() <= 50000).forEach(e->System.out.println(e.getId())); 
            
            // find out the person has highest salary
            Employee e = emps.stream().max((e1,e2)->e1.getSalary()>e2.getSalary()?1:-1).get();
            System.out.println(e);
         }
}
