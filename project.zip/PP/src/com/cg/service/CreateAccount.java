package com.cg.service;

import java.io.IOException;

public interface CreateAccount {
     void createAccount() throws IOException;
}
