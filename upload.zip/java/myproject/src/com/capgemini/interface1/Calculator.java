package com.capgemini.interface1;

public interface Calculator {

	 int addNumber(int x, int y);
	 int square(int x);
}

