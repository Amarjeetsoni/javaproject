package com.capgemini.example;
import java.util.Scanner;
public class Exercise1 {
   static int sum = 0;
	public static boolean check(int num)
   {
	   if(num % 3 == 0 || num % 5 == 0)
		   return true;
	   return false;
   }
   public static int calculateSum(int num)
   {
	   sum = sum + num;
	   return sum;
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      System.out.println("Enter number: ");
      Scanner scan = new Scanner(System.in);
      int num = scan.nextInt();
      int finalSum = 0;
      for(int i = 0; i <= num; i++)
      {
    	  if(check(i))
    	  {
    		  finalSum = calculateSum(i);
    	  }
      }
      System.out.println("Sum of number that are divisible by 3 or 5 is: " + finalSum);
      
	}

}
