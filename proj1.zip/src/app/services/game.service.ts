import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { inject } from '@angular/core/testing';
import { Game } from '../models/game.model';
import {environment} from '../../environments/environment';
@Injectable({
    providedIn: 'root'
})

export class GameService{
    // private baseUrl: string = "/assets/data/games.json";
    
    private baseUrl: string = environment.baseURL;
    // holdes current balance
    private availableBalance: number;

    setBalance(amount: number){
          this.availableBalance = amount;
    }
    getBalance(){
        return this.availableBalance;
    }

    // deducting service charge[100]
    deductServiceCharge(){
        this.availableBalance -= 100;
    }
    constructor(private http: HttpClient){ }
     
    gameGameList(){
        return this.http.get<Game[]>(this.baseUrl);
    }
}