package com.cg.service;

public interface ShowBalance {
    public void showBalance(String user_name, String pass);
}
