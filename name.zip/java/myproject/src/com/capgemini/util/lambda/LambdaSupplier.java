package com.capgemini.util.lambda;

import java.util.function.Predicate;
import java.util.function.Supplier;

public class LambdaSupplier {

	public static void main(String[] args) {
        Supplier<Employee> s1 = Employee::new;
        Employee emp = s1.get();
        System.out.println(emp);
        
        Supplier<Double> rand = ()->Math.random();
        System.out.println(rand.get());
        
        Predicate<Employee> prd = p->p.getSalary() >= 40000;
        System.out.println(prd.test(emp));
        Predicate<Employee> prd1 = p1->p1.getName().equals("Manoj");
        System.out.println(prd1.test(emp));
	}

}
