package com.capgemini.array;
import java.util.Arrays;
import java.util.Scanner;
public class ArrayTest2 {
   public static void main(String[] args) {
	int arr[] = new int[3];
	Scanner scan = new Scanner(System.in);
	for(int i = 0; i < arr.length; i++)
	{
		arr[i] = scan.nextInt();
	}
	System.out.println("Array elemet is: ");
	for(int a: arr)
	{
		System.out.print(a  + " ");
	}
	Arrays.sort(arr);
	System.out.println("Sorted Array elemet is: \n");
	for(int a: arr)
	{
		System.out.print(a  + " ");
	}
}
}
